import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { UserPlus, X, Mail, Shield, User, Info } from "lucide-react";

export default function UserInviteForm({ roles, onCancel, onSuccess }) {
  const [formData, setFormData] = useState({
    email: "",
    full_name: "",
    role: "user",
    custom_role_id: "",
  });
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const activeRoles = roles.filter(r => r.is_active);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setIsSending(true);

    try {
      // Construct the invite URL for the Base44 platform
      // The user will need to manually copy this URL or we guide them to the Dashboard
      const inviteMessage = `
Por favor, convide este usuário através do Dashboard da Base44:

Email: ${formData.email}
Nome: ${formData.full_name}
Tipo de Acesso: ${formData.role === 'admin' ? 'Administrador' : 'Usuário'}
${formData.role === 'user' && formData.custom_role_id ? `Função: ${roles.find(r => r.id === formData.custom_role_id)?.name}` : ''}

Após o usuário aceitar o convite e fazer login, você pode configurar as permissões dele aqui nesta página.
      `.trim();

      // For now, we'll show instructions
      // In a real implementation, you'd integrate with Base44's invite API
      alert(inviteMessage);
      
      if (onSuccess) {
        onSuccess();
      }
    } catch (err) {
      setError(err.message || "Erro ao processar convite");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-purple-600" />
            Convidar Novo Usuário
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-6">
          {/* Info Alert */}
          <Alert className="border-blue-200 bg-blue-50">
            <Info className="w-4 h-4 text-blue-600" />
            <AlertDescription className="text-blue-900 text-sm">
              <strong>Como funciona:</strong> Após preencher este formulário, você será direcionado ao Dashboard da Base44 
              para enviar o convite por email. O usuário receberá um link para criar a conta.
            </AlertDescription>
          </Alert>

          {error && (
            <Alert className="border-red-200 bg-red-50">
              <AlertDescription className="text-red-900">
                {error}
              </AlertDescription>
            </Alert>
          )}

          {/* Basic Info */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="full_name">Nome Completo *</Label>
              <Input
                id="full_name"
                value={formData.full_name}
                onChange={(e) => handleChange('full_name', e.target.value)}
                placeholder="João Silva"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleChange('email', e.target.value)}
                  placeholder="joao.silva@exemplo.com"
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="role">Tipo de Acesso *</Label>
              <Select value={formData.role} onValueChange={(value) => handleChange('role', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-blue-600" />
                      <div>
                        <p className="font-medium">Administrador</p>
                        <p className="text-xs text-slate-500">Acesso total ao sistema</p>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="user">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-600" />
                      <div>
                        <p className="font-medium">Usuário</p>
                        <p className="text-xs text-slate-500">Acesso via função personalizada</p>
                      </div>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.role === 'user' && (
              <div className="space-y-2">
                <Label htmlFor="custom_role">Função Personalizada (Opcional)</Label>
                <Select 
                  value={formData.custom_role_id} 
                  onValueChange={(value) => handleChange('custom_role_id', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma função" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>
                      <span className="text-slate-500">Nenhuma (padrão)</span>
                    </SelectItem>
                    {activeRoles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-indigo-600" />
                          <div>
                            <p className="font-medium">{role.name}</p>
                            {role.description && (
                              <p className="text-xs text-slate-500">{role.description}</p>
                            )}
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  Pode configurar as permissões depois do usuário aceitar o convite
                </p>
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="p-4 bg-slate-50 rounded-lg space-y-2">
            <p className="text-sm font-semibold text-slate-700">Resumo do Convite:</p>
            <div className="text-sm text-slate-600 space-y-1">
              <p><strong>Email:</strong> {formData.email || '—'}</p>
              <p><strong>Nome:</strong> {formData.full_name || '—'}</p>
              <p><strong>Acesso:</strong> {formData.role === 'admin' ? 'Administrador (Total)' : 'Usuário (Limitado)'}</p>
              {formData.role === 'user' && formData.custom_role_id && (
                <p><strong>Função:</strong> {activeRoles.find(r => r.id === formData.custom_role_id)?.name}</p>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button 
            type="submit" 
            disabled={isSending || !formData.email || !formData.full_name}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            {isSending ? 'A processar...' : 'Prosseguir para Convite'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}