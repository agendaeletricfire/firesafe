import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserPlus, X, Mail, Shield, User, Info, Key, AlertTriangle } from "lucide-react";

export default function UserCreateForm({ roles, onSubmit, onCancel, isLoading }) {
  const [activeTab, setActiveTab] = useState("direct");
  const [formData, setFormData] = useState({
    email: "",
    full_name: "",
    password: "",
    confirmPassword: "",
    role: "user",
    custom_role_id: "",
  });
  const [errors, setErrors] = useState({});

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    // Clear error when user types
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: null }));
    }
  };

  const activeRoles = roles.filter(r => r.is_active);

  const validateForm = () => {
    const newErrors = {};

    if (!formData.email) {
      newErrors.email = "Email é obrigatório";
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Email inválido";
    }

    if (!formData.full_name) {
      newErrors.full_name = "Nome é obrigatório";
    }

    if (activeTab === "direct") {
      if (!formData.password) {
        newErrors.password = "Senha é obrigatória";
      } else if (formData.password.length < 6) {
        newErrors.password = "Senha deve ter pelo menos 6 caracteres";
      }

      if (!formData.confirmPassword) {
        newErrors.confirmPassword = "Confirme a senha";
      } else if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = "As senhas não coincidem";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const userData = {
      email: formData.email,
      full_name: formData.full_name,
      role: formData.role,
    };

    if (formData.role === 'user' && formData.custom_role_id) {
      userData.custom_role_id = formData.custom_role_id;
    }

    if (activeTab === "direct") {
      userData.password = formData.password;
      userData.created_directly = true;
    } else {
      userData.invited = true;
    }

    onSubmit(userData, activeTab);
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-purple-600" />
            Adicionar Novo Usuário
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-6">
          {/* Tabs for Direct Create vs Invite */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="direct">
                <Key className="w-4 h-4 mr-2" />
                Criar Diretamente
              </TabsTrigger>
              <TabsTrigger value="invite">
                <Mail className="w-4 h-4 mr-2" />
                Convidar por Email
              </TabsTrigger>
            </TabsList>

            <TabsContent value="direct" className="space-y-4 mt-4">
              <Alert className="border-blue-200 bg-blue-50">
                <Info className="w-4 h-4 text-blue-600" />
                <AlertDescription className="text-blue-900 text-sm">
                  <strong>Criação Direta:</strong> O usuário será criado imediatamente e poderá fazer login com a senha definida.
                </AlertDescription>
              </Alert>

              {/* Basic Info */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="full_name">Nome Completo *</Label>
                  <Input
                    id="full_name"
                    value={formData.full_name}
                    onChange={(e) => handleChange('full_name', e.target.value)}
                    placeholder="João Silva"
                    className={errors.full_name ? "border-red-500" : ""}
                  />
                  {errors.full_name && (
                    <p className="text-xs text-red-600">{errors.full_name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      placeholder="joao.silva@exemplo.com"
                      className={`pl-10 ${errors.email ? "border-red-500" : ""}`}
                    />
                  </div>
                  {errors.email && (
                    <p className="text-xs text-red-600">{errors.email}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Senha *</Label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      id="password"
                      type="password"
                      value={formData.password}
                      onChange={(e) => handleChange('password', e.target.value)}
                      placeholder="Mínimo 6 caracteres"
                      className={`pl-10 ${errors.password ? "border-red-500" : ""}`}
                    />
                  </div>
                  {errors.password && (
                    <p className="text-xs text-red-600">{errors.password}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="confirmPassword">Confirmar Senha *</Label>
                  <div className="relative">
                    <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      id="confirmPassword"
                      type="password"
                      value={formData.confirmPassword}
                      onChange={(e) => handleChange('confirmPassword', e.target.value)}
                      placeholder="Digite a senha novamente"
                      className={`pl-10 ${errors.confirmPassword ? "border-red-500" : ""}`}
                    />
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-xs text-red-600">{errors.confirmPassword}</p>
                  )}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="invite" className="space-y-4 mt-4">
              <Alert className="border-green-200 bg-green-50">
                <Mail className="w-4 h-4 text-green-600" />
                <AlertDescription className="text-green-900 text-sm">
                  <strong>Convite por Email:</strong> O usuário receberá um email com link para criar a conta e definir a senha.
                </AlertDescription>
              </Alert>

              {/* Basic Info for Invite */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="full_name_invite">Nome Completo *</Label>
                  <Input
                    id="full_name_invite"
                    value={formData.full_name}
                    onChange={(e) => handleChange('full_name', e.target.value)}
                    placeholder="João Silva"
                    className={errors.full_name ? "border-red-500" : ""}
                  />
                  {errors.full_name && (
                    <p className="text-xs text-red-600">{errors.full_name}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email_invite">Email *</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                    <Input
                      id="email_invite"
                      type="email"
                      value={formData.email}
                      onChange={(e) => handleChange('email', e.target.value)}
                      placeholder="joao.silva@exemplo.com"
                      className={`pl-10 ${errors.email ? "border-red-500" : ""}`}
                    />
                  </div>
                  {errors.email && (
                    <p className="text-xs text-red-600">{errors.email}</p>
                  )}
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Common Fields - Role and Permissions */}
          <div className="space-y-4 pt-4 border-t border-slate-200">
            <div className="space-y-2">
              <Label htmlFor="role">Tipo de Acesso *</Label>
              <Select value={formData.role} onValueChange={(value) => handleChange('role', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="admin">
                    <div className="flex items-center gap-2">
                      <Shield className="w-4 h-4 text-blue-600" />
                      <div>
                        <p className="font-medium">Administrador</p>
                        <p className="text-xs text-slate-500">Acesso total ao sistema</p>
                      </div>
                    </div>
                  </SelectItem>
                  <SelectItem value="user">
                    <div className="flex items-center gap-2">
                      <User className="w-4 h-4 text-slate-600" />
                      <div>
                        <p className="font-medium">Usuário</p>
                        <p className="text-xs text-slate-500">Acesso via função personalizada</p>
                      </div>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.role === 'user' && (
              <div className="space-y-2">
                <Label htmlFor="custom_role">Função Personalizada (Opcional)</Label>
                <Select 
                  value={formData.custom_role_id} 
                  onValueChange={(value) => handleChange('custom_role_id', value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione uma função" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value={null}>
                      <span className="text-slate-500">Nenhuma (padrão)</span>
                    </SelectItem>
                    {activeRoles.map((role) => (
                      <SelectItem key={role.id} value={role.id}>
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-indigo-600" />
                          <div>
                            <p className="font-medium">{role.name}</p>
                            {role.description && (
                              <p className="text-xs text-slate-500">{role.description}</p>
                            )}
                          </div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-slate-500">
                  Define as permissões específicas do usuário
                </p>
              </div>
            )}
          </div>

          {/* Summary */}
          <div className="p-4 bg-slate-50 rounded-lg space-y-2">
            <p className="text-sm font-semibold text-slate-700">Resumo:</p>
            <div className="text-sm text-slate-600 space-y-1">
              <p><strong>Nome:</strong> {formData.full_name || '—'}</p>
              <p><strong>Email:</strong> {formData.email || '—'}</p>
              <p><strong>Método:</strong> {activeTab === 'direct' ? 'Criação Direta' : 'Convite por Email'}</p>
              <p><strong>Acesso:</strong> {formData.role === 'admin' ? 'Administrador (Total)' : 'Usuário (Limitado)'}</p>
              {formData.role === 'user' && formData.custom_role_id && (
                <p><strong>Função:</strong> {activeRoles.find(r => r.id === formData.custom_role_id)?.name}</p>
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel} disabled={isLoading}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <UserPlus className="w-4 h-4 mr-2" />
            {isLoading ? 'A processar...' : activeTab === 'direct' ? 'Criar Usuário' : 'Enviar Convite'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}