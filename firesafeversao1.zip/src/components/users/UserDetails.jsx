import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Mail, Calendar, Shield, User, X, Save, CheckCircle2, AlertTriangle, Info } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

export default function UserDetails({ user, currentUser, onClose, onUpdate }) {
  const [editingRole, setEditingRole] = useState(false);
  const [newRole, setNewRole] = useState(user.role);
  const [newCustomRoleId, setNewCustomRoleId] = useState(user.custom_role_id || "");
  const [saving, setSaving] = useState(false);

  const { data: roles = [] } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
  });

  const activeRoles = roles.filter(r => r.is_active);
  const userCustomRole = roles.find(r => r.id === user.custom_role_id);
  const selectedCustomRole = roles.find(r => r.id === newCustomRoleId);

  const isCurrentUser = user.id === currentUser.id;

  const handleSaveRole = async () => {
    setSaving(true);
    await onUpdate(user.id, { 
      ...user, 
      role: newRole,
      custom_role_id: newRole === 'user' ? newCustomRoleId : null
    });
    setSaving(false);
    setEditingRole(false);
  };

  const countPermissions = (permissions) => {
    if (!permissions) return 0;
    let count = 0;
    Object.values(permissions).forEach(module => {
      Object.values(module).forEach(perm => {
        if (perm === true) count++;
      });
    });
    return count;
  };

  const getPermissionsList = (permissions) => {
    if (!permissions) return [];
    const list = [];
    Object.entries(permissions).forEach(([module, perms]) => {
      Object.entries(perms).forEach(([action, enabled]) => {
        if (enabled) {
          list.push({ module, action });
        }
      });
    });
    return list;
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            {user.role === 'admin' ? <Shield className="w-5 h-5 text-blue-600" /> : <User className="w-5 h-5 text-slate-600" />}
            Detalhes do Usuário
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {/* User Info */}
        <div className="flex items-center gap-4">
          <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-3xl">
            {user.full_name?.[0]?.toUpperCase() || 'U'}
          </div>
          <div className="flex-1">
            <h3 className="text-2xl font-bold text-slate-900">{user.full_name}</h3>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge className={user.role === 'admin' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-800'}>
                {user.role === 'admin' ? (
                  <><Shield className="w-3 h-3 mr-1" />Administrador</>
                ) : (
                  <><User className="w-3 h-3 mr-1" />Usuário</>
                )}
              </Badge>
              {userCustomRole && (
                <Badge className="bg-indigo-100 text-indigo-800">
                  <Shield className="w-3 h-3 mr-1" />
                  {userCustomRole.name}
                </Badge>
              )}
              {isCurrentUser && (
                <Badge className="bg-green-100 text-green-800">
                  <CheckCircle2 className="w-3 h-3 mr-1" />
                  Você
                </Badge>
              )}
            </div>
          </div>
        </div>

        {/* Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-1">
            <p className="text-sm font-medium text-slate-500">Email</p>
            <div className="flex items-center gap-2 text-slate-900">
              <Mail className="w-4 h-4 text-slate-400" />
              {user.email}
            </div>
          </div>
          <div className="space-y-1">
            <p className="text-sm font-medium text-slate-500">Data de Registo</p>
            <div className="flex items-center gap-2 text-slate-900">
              <Calendar className="w-4 h-4 text-slate-400" />
              {format(new Date(user.created_date), "dd 'de' MMMM, yyyy", { locale: pt })}
            </div>
          </div>
        </div>

        {/* Role Management */}
        {!isCurrentUser && (
          <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
            <div className="flex items-center justify-between">
              <Label className="text-base font-semibold text-slate-900">Gestão de Permissões</Label>
              {!editingRole && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditingRole(true)}
                >
                  Alterar Permissões
                </Button>
              )}
            </div>

            {editingRole ? (
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="role">Tipo de Acesso Base</Label>
                  <Select value={newRole} onValueChange={setNewRole}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="admin">
                        <div className="flex items-center gap-2">
                          <Shield className="w-4 h-4 text-blue-600" />
                          <div>
                            <p className="font-medium">Administrador</p>
                            <p className="text-xs text-slate-500">Acesso total ao sistema</p>
                          </div>
                        </div>
                      </SelectItem>
                      <SelectItem value="user">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-slate-600" />
                          <div>
                            <p className="font-medium">Usuário</p>
                            <p className="text-xs text-slate-500">Acesso via função personalizada</p>
                          </div>
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {newRole === 'user' && (
                  <div className="space-y-2">
                    <Label htmlFor="custom_role">Função Personalizada</Label>
                    <Select value={newCustomRoleId} onValueChange={setNewCustomRoleId}>
                      <SelectTrigger>
                        <SelectValue placeholder="Selecione uma função (opcional)" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value={null}>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-slate-400" />
                            <span>Sem função específica</span>
                          </div>
                        </SelectItem>
                        {activeRoles.map((role) => (
                          <SelectItem key={role.id} value={role.id}>
                            <div className="flex items-center gap-2">
                              <Shield className="w-4 h-4 text-indigo-600" />
                              <div>
                                <p className="font-medium">{role.name}</p>
                                <p className="text-xs text-slate-500">
                                  {countPermissions(role.permissions)} permissões
                                </p>
                              </div>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <Alert className="border-blue-200 bg-blue-50">
                  <Info className="w-4 h-4 text-blue-600" />
                  <AlertDescription className="text-blue-900 text-sm">
                    {newRole === 'admin' ? (
                      <p><strong>Administrador</strong> terá acesso total: gestão de usuários, configurações, licenciamento.</p>
                    ) : selectedCustomRole ? (
                      <p><strong>{selectedCustomRole.name}:</strong> {countPermissions(selectedCustomRole.permissions)} permissões ativas. {selectedCustomRole.description}</p>
                    ) : (
                      <p><strong>Usuário padrão:</strong> Acesso limitado apenas para visualização e criação de dados básicos.</p>
                    )}
                  </AlertDescription>
                </Alert>

                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setEditingRole(false);
                      setNewRole(user.role);
                      setNewCustomRoleId(user.custom_role_id || "");
                    }}
                    className="flex-1"
                  >
                    Cancelar
                  </Button>
                  <Button
                    onClick={handleSaveRole}
                    disabled={saving || (newRole === user.role && newCustomRoleId === (user.custom_role_id || ""))}
                    className="flex-1 bg-blue-600 hover:bg-blue-700"
                  >
                    <Save className="w-4 h-4 mr-2" />
                    {saving ? 'A guardar...' : 'Guardar'}
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <p className="text-sm text-slate-600">
                  Tipo de acesso: <strong className="text-slate-900">{user.role === 'admin' ? 'Administrador' : 'Usuário'}</strong>
                </p>
                {userCustomRole && (
                  <p className="text-sm text-slate-600">
                    Função: <strong className="text-slate-900">{userCustomRole.name}</strong>
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {isCurrentUser && (
          <Alert className="border-orange-200 bg-orange-50">
            <AlertTriangle className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-900">
              <strong>Nota:</strong> Não pode alterar as suas próprias permissões. Outro administrador precisa fazer isso.
            </AlertDescription>
          </Alert>
        )}

        {/* Permissions */}
        <div className="space-y-3">
          <h4 className="font-semibold text-slate-900">Permissões Atuais</h4>
          <div className="space-y-2">
            {user.role === 'admin' ? (
              <>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Acesso total ao sistema</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Gestão de usuários</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Configurações do sistema</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Licenciamento</span>
                </div>
              </>
            ) : userCustomRole ? (
              <>
                <div className="flex items-center gap-2 text-sm text-indigo-700 font-medium">
                  <Shield className="w-4 h-4" />
                  <span>Função: {userCustomRole.name}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-600">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{countPermissions(userCustomRole.permissions)} permissões ativas</span>
                </div>
                <div className="mt-3 p-3 bg-slate-100 rounded-lg max-h-48 overflow-y-auto">
                  <p className="text-xs font-semibold text-slate-700 mb-2">Detalhes das Permissões:</p>
                  <div className="space-y-1 text-xs">
                    {getPermissionsList(userCustomRole.permissions).map((perm, i) => (
                      <div key={i} className="flex items-center gap-2 text-slate-600">
                        <CheckCircle2 className="w-3 h-3 text-green-600" />
                        <span>{perm.module}: {perm.action}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2 text-sm text-green-700">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Ver e criar dados básicos</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <X className="w-4 h-4" />
                  <span>Sem acesso a configurações</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <X className="w-4 h-4" />
                  <span>Sem gestão de usuários</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <X className="w-4 h-4" />
                  <span>Sem acesso a licenciamento</span>
                </div>
              </>
            )}
          </div>
        </div>
      </CardContent>
      <CardFooter className="border-t border-slate-100 flex justify-end">
        <Button onClick={onClose} variant="outline">
          Fechar
        </Button>
      </CardFooter>
    </Card>
  );
}