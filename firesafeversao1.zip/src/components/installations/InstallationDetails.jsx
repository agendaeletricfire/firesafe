
import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Layers, AlertCircle, Edit, X, Building2, FileText } from "lucide-react";

export default function InstallationDetails({ installation, clientName, onClose, onEdit }) {
  const getTypeLabel = (type) => {
    const types = {
      residential: 'Residencial',
      commercial: 'Comercial',
      industrial: 'Industrial',
      public: 'Público',
      warehouse: 'Armazém',
      office: 'Escritório'
    };
    return types[type] || type;
  };

  const getRiskLabel = (risk) => {
    switch(risk) {
      case 'low': return 'Baixo';
      case 'medium': return 'Médio';
      case 'high': return 'Alto';
      case 'very_high': return 'Muito Alto';
      default: return risk;
    }
  };

  const getRiskColor = (risk) => {
    switch(risk) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'very_high': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-purple-600" />
            Detalhes da Instalação
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-2xl font-bold text-slate-900">{installation.name}</h3>
            <p className="text-slate-500 mt-1">{clientName}</p>
          </div>
          <Badge className={installation.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
            {installation.status === 'active' ? 'Ativa' : 'Inativa'}
          </Badge>
        </div>

        <div className="flex gap-2">
          <Badge variant="outline">{getTypeLabel(installation.type)}</Badge>
          <Badge className={getRiskColor(installation.risk_level)}>
            <AlertCircle className="w-3 h-3 mr-1" />
            Risco {getRiskLabel(installation.risk_level)}
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {installation.area_m2 && (
            <div className="space-y-1">
              <p className="text-sm font-medium text-slate-500">Área</p>
              <div className="flex items-center gap-2 text-slate-900">
                <Layers className="w-4 h-4 text-slate-400" />
                {installation.area_m2} m²
              </div>
            </div>
          )}
          {installation.floors && (
            <div className="space-y-1">
              <p className="text-sm font-medium text-slate-500">Pisos</p>
              <p className="text-slate-900">{installation.floors}</p>
            </div>
          )}
        </div>

        {(installation.address || installation.city || installation.postal_code) && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-500">Morada</p>
            <div className="flex items-start gap-2 text-slate-900">
              <MapPin className="w-4 h-4 text-slate-400 mt-1" />
              <div>
                {installation.address && <p>{installation.address}</p>}
                {(installation.postal_code || installation.city) && (
                  <p>{installation.postal_code} {installation.city}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {installation.notes && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-500">Observações</p>
            <div className="flex items-start gap-2">
              <FileText className="w-4 h-4 text-slate-400 mt-1" />
              <p className="text-slate-900">{installation.notes}</p>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-slate-100 flex justify-end">
        {onEdit && (
          <Button onClick={() => onEdit(installation)} className="bg-purple-600 hover:bg-purple-700">
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
