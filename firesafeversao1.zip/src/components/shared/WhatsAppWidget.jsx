import React, { useState } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";

export default function WhatsAppWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  
  // Load config from database - works without authentication
  const { data: configs = [] } = useQuery({
    queryKey: ['whatsapp-config'],
    queryFn: async () => {
      try {
        return await base44.entities.WhatsAppConfig.list();
      } catch (error) {
        console.log("Could not load WhatsApp config, using defaults");
        return [];
      }
    },
    retry: false,
    staleTime: 60000, // Cache for 1 minute
  });

  const config = configs.find(c => c.is_active) || {
    whatsapp_number: "351912345678",
    widget_enabled: true,
    welcome_message: "👋 Olá! Bem-vindo ao FireSafe Pro\n\nComo podemos ajudá-lo hoje?",
    quick_messages: [
      "Olá! Preciso de agendar uma manutenção 🔧",
      "Gostaria de informações sobre serviços 📋",
      "Tenho uma emergência! ⚠️",
      "Quero fazer uma consulta 💬"
    ],
    business_hours: { enabled: false, message: "" }
  };

  // Don't render if widget is disabled or no number configured
  if (!config.widget_enabled || !config.whatsapp_number) return null;

  const handleSendMessage = (customMessage = null) => {
    const messageToSend = customMessage || message;
    if (!messageToSend.trim()) return;
    
    // Formatar mensagem para WhatsApp
    const encodedMessage = encodeURIComponent(messageToSend);
    const whatsappURL = `https://wa.me/${config.whatsapp_number}?text=${encodedMessage}`;
    
    // Abrir WhatsApp em nova aba
    window.open(whatsappURL, '_blank');
    
    // Resetar e fechar
    setMessage("");
    setIsOpen(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <>
      {/* Chat Widget Window */}
      {isOpen && (
        <Card className="fixed bottom-24 right-6 w-80 md:w-96 shadow-2xl border-none z-[9999] animate-in slide-in-from-bottom-5 duration-300">
          <CardHeader className="bg-gradient-to-r from-green-600 to-green-700 text-white rounded-t-lg pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-lg">
                  <MessageCircle className="w-7 h-7 text-green-600" />
                </div>
                <div>
                  <CardTitle className="text-lg">FireSafe Pro</CardTitle>
                  <p className="text-xs text-green-100">Estamos online! 🟢</p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-green-700 rounded-full"
              >
                <X className="w-5 h-5" />
              </Button>
            </div>
          </CardHeader>
          
          <CardContent className="p-4 space-y-4">
            {/* Mensagem de Boas-Vindas */}
            <div className="bg-green-50 rounded-lg p-3 border border-green-200">
              <p className="text-sm text-slate-700 whitespace-pre-wrap">
                {config.welcome_message}
              </p>
            </div>

            {/* Business Hours */}
            {config.business_hours?.enabled && (
              <div className="text-xs text-slate-500 bg-slate-50 rounded p-2 border border-slate-200">
                {config.business_hours.message}
              </div>
            )}

            {/* Mensagens Rápidas */}
            {config.quick_messages?.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs font-semibold text-slate-600">Mensagens rápidas:</p>
                {config.quick_messages.map((msg, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(msg)}
                    className="w-full text-left px-3 py-2 text-sm bg-white border border-slate-200 rounded-lg hover:bg-green-50 hover:border-green-300 transition-all"
                  >
                    {msg}
                  </button>
                ))}
              </div>
            )}

            {/* Campo de Mensagem Personalizada */}
            <div className="space-y-2">
              <p className="text-xs font-semibold text-slate-600">Ou escreva sua mensagem:</p>
              <div className="relative">
                <Textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Digite sua mensagem..."
                  className="resize-none pr-12 text-sm"
                  rows={3}
                />
                <Button
                  onClick={() => handleSendMessage()}
                  disabled={!message.trim()}
                  className="absolute bottom-2 right-2 h-8 w-8 p-0 bg-green-600 hover:bg-green-700"
                  size="icon"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Rodapé */}
            <div className="flex items-center justify-center gap-2 pt-2 border-t border-slate-200">
              <MessageCircle className="w-4 h-4 text-green-600" />
              <p className="text-xs text-slate-500">
                Resposta rápida via <strong>WhatsApp</strong>
              </p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`fixed bottom-6 right-6 w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white rounded-full shadow-2xl flex items-center justify-center z-[9999] transition-all duration-300 hover:scale-110 ${
          isOpen ? 'scale-0' : 'scale-100'
        }`}
        aria-label="Abrir chat WhatsApp"
      >
        <MessageCircle className="w-8 h-8" />
        
        {/* Pulsing Animation */}
        <span className="absolute inset-0 rounded-full bg-green-400 animate-ping opacity-75"></span>
        
        {/* Notification Badge */}
        <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs font-bold rounded-full flex items-center justify-center border-2 border-white">
          1
        </span>
      </button>
    </>
  );
}