import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Lock } from "lucide-react";

// Helper function
function isAdmin(user) {
  return user?.role === 'admin';
}

function hasPermission(user, userRole, module, action) {
  if (user?.role === 'admin') {
    return true;
  }

  if (!userRole || !userRole.permissions) {
    return false;
  }

  if (!userRole.is_active) {
    return false;
  }

  const modulePerms = userRole.permissions[module];
  if (!modulePerms) {
    return false;
  }

  return modulePerms[action] === true;
}

export default function PermissionGuard({ 
  module, 
  action = 'view', 
  children, 
  fallback = null,
  showDenied = true 
}) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  const { data: roles = [] } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
    enabled: !!user && user.role !== 'admin',
  });

  const userRole = roles.find(r => r.id === user?.custom_role_id);

  if (!user) {
    return null;
  }

  const allowed = hasPermission(user, userRole, module, action);

  if (!allowed) {
    if (fallback) {
      return fallback;
    }

    if (showDenied) {
      return (
        <div className="p-6">
          <Alert className="border-red-200 bg-red-50">
            <Lock className="w-4 h-4 text-red-600" />
            <AlertDescription className="text-red-900">
              <strong>Acesso Negado:</strong> Não tem permissão para aceder a este conteúdo.
            </AlertDescription>
          </Alert>
        </div>
      );
    }

    return null;
  }

  return children;
}

export function usePermissions(module) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  const { data: roles = [] } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
    enabled: !!user && user.role !== 'admin',
  });

  const userRole = roles.find(r => r.id === user?.custom_role_id);

  return {
    user,
    userRole,
    isAdmin: isAdmin(user),
    canView: hasPermission(user, userRole, module, 'view'),
    canCreate: hasPermission(user, userRole, module, 'create'),
    canEdit: hasPermission(user, userRole, module, 'edit'),
    canDelete: hasPermission(user, userRole, module, 'delete'),
  };
}