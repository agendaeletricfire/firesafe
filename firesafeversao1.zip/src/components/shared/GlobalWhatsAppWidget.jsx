import React, { useState, useEffect } from "react";
import { MessageCircle, X, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { createRoot } from "react-dom/client";

// Este componente renderiza globalmente, mesmo sem React Router
function WhatsAppWidgetContent() {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const [config, setConfig] = useState({
    whatsapp_number: "351912345678",
    widget_enabled: true,
    welcome_message: "👋 Olá! Bem-vindo ao FireSafe Pro\n\nComo podemos ajudá-lo hoje?",
    quick_messages: [
      "Olá! Preciso de agendar uma manutenção 🔧",
      "Gostaria de informações sobre serviços 📋",
      "Tenho uma emergência! ⚠️",
      "Quero fazer uma consulta 💬"
    ],
    business_hours: { enabled: false, message: "" }
  });

  useEffect(() => {
    // Tentar carregar configuração da API
    const loadConfig = async () => {
      try {
        const response = await fetch('/api/entities/WhatsAppConfig/list', {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
          },
        });
        
        if (response.ok) {
          const data = await response.json();
          const activeConfig = data.find(c => c.is_active);
          if (activeConfig) {
            setConfig(activeConfig);
          }
        }
      } catch (error) {
        console.log("Using default WhatsApp config");
      }
    };

    loadConfig();
  }, []);

  if (!config.widget_enabled || !config.whatsapp_number) return null;

  const handleSendMessage = (customMessage = null) => {
    const messageToSend = customMessage || message;
    if (!messageToSend.trim()) return;
    
    const encodedMessage = encodeURIComponent(messageToSend);
    const whatsappURL = `https://wa.me/${config.whatsapp_number}?text=${encodedMessage}`;
    
    window.open(whatsappURL, '_blank');
    
    setMessage("");
    setIsOpen(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <div className="whatsapp-widget-container">
      <style>{`
        .whatsapp-widget-container {
          position: fixed;
          z-index: 999999 !important;
        }
        
        .whatsapp-chat-card {
          position: fixed;
          bottom: 6.5rem;
          right: 1.5rem;
          width: 20rem;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          border: none;
          z-index: 999999;
          animation: slideInUp 0.3s ease-out;
          background: white;
          border-radius: 1rem;
          overflow: hidden;
        }
        
        @media (min-width: 768px) {
          .whatsapp-chat-card {
            width: 24rem;
          }
        }
        
        .whatsapp-floating-btn {
          position: fixed;
          bottom: 1.5rem;
          right: 1.5rem;
          width: 4rem;
          height: 4rem;
          background: linear-gradient(to bottom right, #22c55e, #16a34a);
          color: white;
          border-radius: 9999px;
          box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 999999;
          cursor: pointer;
          border: none;
          transition: all 0.3s;
        }
        
        .whatsapp-floating-btn:hover {
          transform: scale(1.1);
          background: linear-gradient(to bottom right, #16a34a, #15803d);
        }
        
        .whatsapp-floating-btn.hidden {
          transform: scale(0);
        }
        
        .whatsapp-pulse {
          position: absolute;
          inset: 0;
          border-radius: 9999px;
          background: #22c55e;
          animation: ping 1.5s cubic-bezier(0, 0, 0.2, 1) infinite;
          opacity: 0.75;
        }
        
        .whatsapp-badge {
          position: absolute;
          top: -0.25rem;
          right: -0.25rem;
          width: 1.25rem;
          height: 1.25rem;
          background: #ef4444;
          color: white;
          font-size: 0.75rem;
          font-weight: bold;
          border-radius: 9999px;
          display: flex;
          align-items: center;
          justify-content: center;
          border: 2px solid white;
        }
        
        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes ping {
          75%, 100% {
            transform: scale(1.5);
            opacity: 0;
          }
        }
      `}</style>

      {/* Chat Window */}
      {isOpen && (
        <div className="whatsapp-chat-card">
          {/* Header */}
          <div style={{
            background: 'linear-gradient(to right, #16a34a, #15803d)',
            color: 'white',
            padding: '1rem',
          }}>
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                <div style={{
                  width: '3rem',
                  height: '3rem',
                  background: 'white',
                  borderRadius: '9999px',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                }}>
                  <MessageCircle size={28} color="#16a34a" />
                </div>
                <div>
                  <div style={{ fontSize: '1.125rem', fontWeight: 'bold' }}>FireSafe Pro</div>
                  <div style={{ fontSize: '0.75rem', color: 'rgba(255, 255, 255, 0.9)' }}>
                    Estamos online! 🟢
                  </div>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                style={{
                  background: 'transparent',
                  border: 'none',
                  color: 'white',
                  cursor: 'pointer',
                  padding: '0.5rem',
                  borderRadius: '0.5rem',
                  transition: 'background 0.2s',
                }}
                onMouseEnter={(e) => e.target.style.background = 'rgba(255, 255, 255, 0.1)'}
                onMouseLeave={(e) => e.target.style.background = 'transparent'}
              >
                <X size={20} />
              </button>
            </div>
          </div>

          {/* Content */}
          <div style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
            {/* Welcome Message */}
            <div style={{
              background: '#f0fdf4',
              borderRadius: '0.5rem',
              padding: '0.75rem',
              border: '1px solid #bbf7d0',
            }}>
              <p style={{
                fontSize: '0.875rem',
                color: '#334155',
                whiteSpace: 'pre-wrap',
                margin: 0,
              }}>
                {config.welcome_message}
              </p>
            </div>

            {/* Business Hours */}
            {config.business_hours?.enabled && (
              <div style={{
                fontSize: '0.75rem',
                color: '#64748b',
                background: '#f8fafc',
                borderRadius: '0.25rem',
                padding: '0.5rem',
                border: '1px solid #e2e8f0',
              }}>
                {config.business_hours.message}
              </div>
            )}

            {/* Quick Messages */}
            {config.quick_messages?.length > 0 && (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                <p style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569', margin: 0 }}>
                  Mensagens rápidas:
                </p>
                {config.quick_messages.map((msg, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(msg)}
                    style={{
                      width: '100%',
                      textAlign: 'left',
                      padding: '0.5rem 0.75rem',
                      fontSize: '0.875rem',
                      background: 'white',
                      border: '1px solid #e2e8f0',
                      borderRadius: '0.5rem',
                      cursor: 'pointer',
                      transition: 'all 0.2s',
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.background = '#f0fdf4';
                      e.target.style.borderColor = '#86efac';
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.background = 'white';
                      e.target.style.borderColor = '#e2e8f0';
                    }}
                  >
                    {msg}
                  </button>
                ))}
              </div>
            )}

            {/* Custom Message */}
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
              <p style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569', margin: 0 }}>
                Ou escreva sua mensagem:
              </p>
              <div style={{ position: 'relative' }}>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Digite sua mensagem..."
                  rows={3}
                  style={{
                    width: '100%',
                    padding: '0.5rem',
                    paddingRight: '3rem',
                    fontSize: '0.875rem',
                    border: '1px solid #e2e8f0',
                    borderRadius: '0.5rem',
                    resize: 'none',
                    fontFamily: 'inherit',
                  }}
                />
                <button
                  onClick={() => handleSendMessage()}
                  disabled={!message.trim()}
                  style={{
                    position: 'absolute',
                    bottom: '0.5rem',
                    right: '0.5rem',
                    width: '2rem',
                    height: '2rem',
                    padding: 0,
                    background: message.trim() ? '#16a34a' : '#94a3b8',
                    border: 'none',
                    borderRadius: '0.25rem',
                    cursor: message.trim() ? 'pointer' : 'not-allowed',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'white',
                  }}
                >
                  <Send size={16} />
                </button>
              </div>
            </div>

            {/* Footer */}
            <div style={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '0.5rem',
              paddingTop: '0.5rem',
              borderTop: '1px solid #e2e8f0',
            }}>
              <MessageCircle size={16} color="#16a34a" />
              <p style={{ fontSize: '0.75rem', color: '#64748b', margin: 0 }}>
                Resposta rápida via <strong>WhatsApp</strong>
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Floating Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`whatsapp-floating-btn ${isOpen ? 'hidden' : ''}`}
        aria-label="Abrir chat WhatsApp"
      >
        <MessageCircle size={32} />
        <span className="whatsapp-pulse"></span>
        <span className="whatsapp-badge">1</span>
      </button>
    </div>
  );
}

// Auto-inicialização quando o script carrega
if (typeof window !== 'undefined') {
  // Aguarda o DOM estar pronto
  const initWidget = () => {
    // Verifica se já existe um container
    let container = document.getElementById('global-whatsapp-widget');
    
    if (!container) {
      // Cria o container
      container = document.createElement('div');
      container.id = 'global-whatsapp-widget';
      document.body.appendChild(container);
      
      // Renderiza o widget
      const root = createRoot(container);
      root.render(<WhatsAppWidgetContent />);
    }
  };

  // Inicializa quando o DOM estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initWidget);
  } else {
    initWidget();
  }
}

export default WhatsAppWidgetContent;