
import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Mail, Phone, MapPin, Calendar, Edit, X, Building, FileText } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

export default function ClientDetails({ client, onClose, onEdit }) {
  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Building className="w-5 h-5 text-blue-600" />
            Detalhes do Cliente
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <h3 className="text-2xl font-bold text-slate-900">{client.name}</h3>
            {client.company && (
              <p className="text-slate-500 mt-1">{client.company}</p>
            )}
          </div>
          <Badge className={client.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
            {client.status === 'active' ? 'Ativo' : 'Inativo'}
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {client.nif && (
            <div className="space-y-1">
              <p className="text-sm font-medium text-slate-500">NIF/NIPC</p>
              <p className="text-slate-900">{client.nif}</p>
            </div>
          )}
          <div className="space-y-1">
            <p className="text-sm font-medium text-slate-500">Email</p>
            <div className="flex items-center gap-2 text-slate-900">
              <Mail className="w-4 h-4 text-slate-400" />
              {client.email}
            </div>
          </div>
          {client.phone && (
            <div className="space-y-1">
              <p className="text-sm font-medium text-slate-500">Telefone</p>
              <div className="flex items-center gap-2 text-slate-900">
                <Phone className="w-4 h-4 text-slate-400" />
                {client.phone}
              </div>
            </div>
          )}
          {client.contract_start && (
            <div className="space-y-1">
              <p className="text-sm font-medium text-slate-500">Início do Contrato</p>
              <div className="flex items-center gap-2 text-slate-900">
                <Calendar className="w-4 h-4 text-slate-400" />
                {format(new Date(client.contract_start), "dd 'de' MMMM, yyyy", { locale: pt })}
              </div>
            </div>
          )}
        </div>

        {(client.address || client.city || client.postal_code) && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-500">Morada</p>
            <div className="flex items-start gap-2 text-slate-900">
              <MapPin className="w-4 h-4 text-slate-400 mt-1" />
              <div>
                {client.address && <p>{client.address}</p>}
                {(client.postal_code || client.city) && (
                  <p>{client.postal_code} {client.city}</p>
                )}
              </div>
            </div>
          </div>
        )}

        {client.notes && (
          <div className="space-y-2">
            <p className="text-sm font-medium text-slate-500">Observações</p>
            <div className="flex items-start gap-2">
              <FileText className="w-4 h-4 text-slate-400 mt-1" />
              <p className="text-slate-900">{client.notes}</p>
            </div>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-slate-100 flex justify-end">
        {onEdit && (
          <Button onClick={() => onEdit(client)} className="bg-blue-600 hover:bg-blue-700">
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
