import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Plus, Trash2, GripVertical } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function TemplateForm({ template, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(template || {
    name: "",
    description: "",
    standard: "EN54",
    items: [],
    is_default: false,
    status: "active"
  });

  const [newItem, setNewItem] = useState({
    key: "",
    label: "",
    category: "inspection",
    required: true,
    order: formData.items.length
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const addItem = () => {
    if (!newItem.label) return;
    
    const key = newItem.label
      .toLowerCase()
      .replace(/[^a-z0-9\s]/g, '')
      .replace(/\s+/g, '_')
      .substring(0, 50);

    setFormData(prev => ({
      ...prev,
      items: [...prev.items, { ...newItem, key, order: prev.items.length }]
    }));
    
    setNewItem({
      key: "",
      label: "",
      category: "inspection",
      required: true,
      order: formData.items.length + 1
    });
  };

  const removeItem = (index) => {
    setFormData(prev => ({
      ...prev,
      items: prev.items.filter((_, i) => i !== index).map((item, i) => ({ ...item, order: i }))
    }));
  };

  const moveItem = (index, direction) => {
    const newItems = [...formData.items];
    const newIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (newIndex < 0 || newIndex >= newItems.length) return;
    
    [newItems[index], newItems[newIndex]] = [newItems[newIndex], newItems[index]];
    
    setFormData(prev => ({
      ...prev,
      items: newItems.map((item, i) => ({ ...item, order: i }))
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const getCategoryLabel = (category) => {
    const labels = {
      inspection: "Inspeção",
      testing: "Testes",
      documentation: "Documentação",
      equipment: "Equipamento",
      safety: "Segurança"
    };
    return labels[category] || category;
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle>{template ? 'Editar Template' : 'Novo Template'}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome do Template *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="Ex: EN54 Standard"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="standard">Norma/Padrão</Label>
              <Select value={formData.standard} onValueChange={(value) => handleChange('standard', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="EN54">EN54 (Europa)</SelectItem>
                  <SelectItem value="LPCB">LPCB (UK)</SelectItem>
                  <SelectItem value="NFPA">NFPA (USA)</SelectItem>
                  <SelectItem value="Custom">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Descrição do template..."
                rows={2}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Ativo</SelectItem>
                  <SelectItem value="inactive">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2 pt-6">
              <Checkbox
                id="is_default"
                checked={formData.is_default}
                onCheckedChange={(checked) => handleChange('is_default', checked)}
              />
              <Label htmlFor="is_default" className="cursor-pointer">
                Definir como template padrão
              </Label>
            </div>
          </div>

          {/* Items */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">Itens da Checklist</h3>
              <Badge variant="outline">{formData.items.length} itens</Badge>
            </div>

            {/* Add New Item */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4 p-4 bg-indigo-50 rounded-lg">
              <div className="space-y-2 md:col-span-5">
                <Label htmlFor="item_label" className="text-xs">Item *</Label>
                <Input
                  id="item_label"
                  value={newItem.label}
                  onChange={(e) => setNewItem({...newItem, label: e.target.value})}
                  placeholder="Ex: Inspeção visual completa"
                />
              </div>
              <div className="space-y-2 md:col-span-3">
                <Label htmlFor="item_category" className="text-xs">Categoria</Label>
                <Select value={newItem.category} onValueChange={(value) => setNewItem({...newItem, category: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inspection">Inspeção</SelectItem>
                    <SelectItem value="testing">Testes</SelectItem>
                    <SelectItem value="documentation">Documentação</SelectItem>
                    <SelectItem value="equipment">Equipamento</SelectItem>
                    <SelectItem value="safety">Segurança</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2 md:col-span-3 flex items-end">
                <div className="flex items-center gap-2 h-10">
                  <Checkbox
                    id="item_required"
                    checked={newItem.required}
                    onCheckedChange={(checked) => setNewItem({...newItem, required: checked})}
                  />
                  <Label htmlFor="item_required" className="cursor-pointer text-xs">
                    Obrigatório
                  </Label>
                </div>
              </div>
              <div className="md:col-span-1 flex items-end">
                <Button type="button" onClick={addItem} className="w-full">
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Items List */}
            {formData.items.length > 0 ? (
              <div className="space-y-2">
                {formData.items.map((item, index) => (
                  <div key={index} className="flex items-center gap-3 p-3 bg-white border rounded-lg">
                    <div className="flex flex-col gap-1">
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => moveItem(index, 'up')}
                        disabled={index === 0}
                        className="h-4 w-4 p-0"
                      >
                        <GripVertical className="w-3 h-3" />
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        onClick={() => moveItem(index, 'down')}
                        disabled={index === formData.items.length - 1}
                        className="h-4 w-4 p-0"
                      >
                        <GripVertical className="w-3 h-3" />
                      </Button>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400 text-xs font-mono">{index + 1}.</span>
                        <span className="font-medium text-sm">{item.label}</span>
                        <Badge variant="outline" className="text-xs">
                          {getCategoryLabel(item.category)}
                        </Badge>
                        {item.required && (
                          <Badge className="bg-red-100 text-red-800 text-xs">Obrigatório</Badge>
                        )}
                      </div>
                      <p className="text-xs text-slate-500 ml-6">Chave: {item.key}</p>
                    </div>
                    <Button 
                      type="button" 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => removeItem(index)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 bg-slate-50 rounded-lg">
                <p className="text-slate-500 text-sm">Nenhum item adicionado</p>
                <p className="text-slate-400 text-xs mt-1">Adicione itens para criar a checklist</p>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button type="submit" disabled={isLoading || formData.items.length === 0} className="bg-indigo-600 hover:bg-indigo-700">
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? 'A guardar...' : 'Guardar Template'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}