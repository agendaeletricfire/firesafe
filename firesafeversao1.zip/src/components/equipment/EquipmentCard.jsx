
import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, AlertTriangle, CheckCircle2, Edit, Shield } from "lucide-react";
import { format, isBefore, addDays } from "date-fns";
import { pt } from "date-fns/locale";

export default function EquipmentCard({ equipment, installations, onEdit }) {
  const getTypeLabel = (type) => {
    const types = {
      extinguisher: 'Extintor',
      fire_alarm: 'Alarme',
      smoke_detector: 'Detector',
      sprinkler: 'Sprinkler',
      fire_hose: 'Mangueira',
      emergency_lighting: 'Iluminação',
      fire_door: 'Porta',
      control_panel: 'Painel'
    };
    return types[type] || type;
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'operational': return 'bg-green-100 text-green-800';
      case 'needs_maintenance': return 'bg-orange-100 text-orange-800';
      case 'needs_replacement': return 'bg-red-100 text-red-800';
      case 'out_of_service': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getStatusLabel = (status) => {
    const labels = {
      operational: 'Operacional',
      needs_maintenance: 'Manutenção',
      needs_replacement: 'Substituição',
      out_of_service: 'Fora de Serviço'
    };
    return labels[status] || status;
  };

  const installation = installations.find(i => i.id === equipment.installation_id);
  const isExpiringSoon = equipment.expiry_date && isBefore(new Date(equipment.expiry_date), addDays(new Date(), 30));
  const needsInspection = equipment.next_inspection && isBefore(new Date(equipment.next_inspection), new Date());

  return (
    <Card className="border-none shadow-md hover:shadow-lg transition-all">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg text-slate-900 flex items-center gap-2">
              {getTypeLabel(equipment.type)}
              {equipment.en54_compliant && (
                <Shield className="w-4 h-4 text-blue-600" title="Conforme EN54" />
              )}
            </CardTitle>
            {equipment.model && (
              <p className="text-sm text-slate-500 mt-1">{equipment.model}</p>
            )}
          </div>
          <Badge className={getStatusColor(equipment.status)}>
            {getStatusLabel(equipment.status)}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {installation && (
          <p className="text-sm text-slate-600 font-medium">{installation.name}</p>
        )}
        {equipment.location && (
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <MapPin className="w-4 h-4" />
            <span>{equipment.location}</span>
          </div>
        )}
        {equipment.next_inspection && (
          <div className="flex items-center gap-2 text-sm">
            <Calendar className="w-4 h-4" />
            <span className={needsInspection ? 'text-red-600 font-medium' : 'text-slate-600'}>
              Próxima inspeção: {format(new Date(equipment.next_inspection), "dd/MM/yyyy")}
            </span>
          </div>
        )}
        {isExpiringSoon && (
          <div className="flex items-center gap-2 p-2 bg-orange-50 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-orange-600" />
            <span className="text-xs text-orange-700">Validade próxima</span>
          </div>
        )}
        {needsInspection && (
          <div className="flex items-center gap-2 p-2 bg-red-50 rounded-lg">
            <AlertTriangle className="w-4 h-4 text-red-600" />
            <span className="text-xs text-red-700">Inspeção atrasada</span>
          </div>
        )}
      </CardContent>
      <CardFooter className="border-t border-slate-100 p-4">
        {onEdit && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => onEdit(equipment)}
            className="w-full"
          >
            <Edit className="w-3 h-3 mr-2" />
            Editar
          </Button>
        )}
      </CardFooter>
    </Card>
  );
}
