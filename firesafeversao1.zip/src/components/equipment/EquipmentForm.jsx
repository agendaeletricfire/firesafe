import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X } from "lucide-react";

export default function EquipmentForm({ equipment, installations, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(equipment || {
    installation_id: "",
    type: "extinguisher",
    model: "",
    manufacturer: "",
    serial_number: "",
    location: "",
    installation_date: "",
    expiry_date: "",
    last_inspection: "",
    next_inspection: "",
    status: "operational",
    en54_compliant: true,
    notes: ""
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle>{equipment ? 'Editar Equipamento' : 'Novo Equipamento'}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="installation_id">Instalação *</Label>
              <Select value={formData.installation_id} onValueChange={(value) => handleChange('installation_id', value)} required>
                <SelectTrigger>
                  <SelectValue placeholder="Selecionar instalação" />
                </SelectTrigger>
                <SelectContent>
                  {installations.map(inst => (
                    <SelectItem key={inst.id} value={inst.id}>{inst.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="type">Tipo *</Label>
              <Select value={formData.type} onValueChange={(value) => handleChange('type', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="extinguisher">Extintor</SelectItem>
                  <SelectItem value="fire_alarm">Alarme de Incêndio</SelectItem>
                  <SelectItem value="smoke_detector">Detector de Fumo</SelectItem>
                  <SelectItem value="sprinkler">Sprinkler</SelectItem>
                  <SelectItem value="fire_hose">Mangueira de Incêndio</SelectItem>
                  <SelectItem value="emergency_lighting">Iluminação de Emergência</SelectItem>
                  <SelectItem value="fire_door">Porta Corta-fogo</SelectItem>
                  <SelectItem value="control_panel">Painel de Controlo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="manufacturer">Fabricante</Label>
              <Input
                id="manufacturer"
                value={formData.manufacturer}
                onChange={(e) => handleChange('manufacturer', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="model">Modelo</Label>
              <Input
                id="model"
                value={formData.model}
                onChange={(e) => handleChange('model', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="serial_number">Número de Série</Label>
              <Input
                id="serial_number"
                value={formData.serial_number}
                onChange={(e) => handleChange('serial_number', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Localização</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleChange('location', e.target.value)}
                placeholder="Ex: Piso 1, Corredor A"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="installation_date">Data de Instalação</Label>
              <Input
                id="installation_date"
                type="date"
                value={formData.installation_date}
                onChange={(e) => handleChange('installation_date', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="expiry_date">Data de Validade</Label>
              <Input
                id="expiry_date"
                type="date"
                value={formData.expiry_date}
                onChange={(e) => handleChange('expiry_date', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="last_inspection">Última Inspeção</Label>
              <Input
                id="last_inspection"
                type="date"
                value={formData.last_inspection}
                onChange={(e) => handleChange('last_inspection', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="next_inspection">Próxima Inspeção</Label>
              <Input
                id="next_inspection"
                type="date"
                value={formData.next_inspection}
                onChange={(e) => handleChange('next_inspection', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="operational">Operacional</SelectItem>
                  <SelectItem value="needs_maintenance">Necessita Manutenção</SelectItem>
                  <SelectItem value="needs_replacement">Necessita Substituição</SelectItem>
                  <SelectItem value="out_of_service">Fora de Serviço</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 flex items-center gap-2 pt-8">
              <Checkbox
                id="en54_compliant"
                checked={formData.en54_compliant}
                onCheckedChange={(checked) => handleChange('en54_compliant', checked)}
              />
              <Label htmlFor="en54_compliant" className="cursor-pointer">Conforme norma EN54</Label>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                rows={3}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button type="submit" disabled={isLoading} className="bg-green-600 hover:bg-green-700">
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? 'A guardar...' : 'Guardar'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}