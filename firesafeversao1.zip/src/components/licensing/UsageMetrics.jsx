import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Users, Building2, TrendingUp, AlertTriangle } from "lucide-react";

export default function UsageMetrics({ license, currentClients, currentUsers, currentInstallations }) {
  const clientsPercentage = (currentClients / license.max_clients) * 100;
  const usersPercentage = (currentUsers / license.max_users) * 100;

  const getProgressColor = (percentage) => {
    if (percentage >= 90) return 'bg-red-500';
    if (percentage >= 75) return 'bg-orange-500';
    if (percentage >= 50) return 'bg-yellow-500';
    return 'bg-green-500';
  };

  const getStatusIcon = (percentage) => {
    if (percentage >= 90) return <AlertTriangle className="w-4 h-4 text-red-600" />;
    return <TrendingUp className="w-4 h-4 text-green-600" />;
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {/* Clients Usage */}
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-base flex items-center gap-2">
            <Building2 className="w-5 h-5 text-blue-600" />
            Clientes
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-3xl font-bold text-slate-900">{currentClients}</p>
                <p className="text-sm text-slate-500">de {license.max_clients} máximo</p>
              </div>
              {getStatusIcon(clientsPercentage)}
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Uso</span>
                <span className="font-semibold text-slate-900">{clientsPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={clientsPercentage} className="h-3" />
            </div>
            {clientsPercentage >= 90 && (
              <p className="text-xs text-red-600 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Limite quase atingido!
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Users Usage */}
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="w-5 h-5 text-purple-600" />
            Usuários
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-3xl font-bold text-slate-900">{currentUsers}</p>
                <p className="text-sm text-slate-500">de {license.max_users} máximo</p>
              </div>
              {getStatusIcon(usersPercentage)}
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-600">Uso</span>
                <span className="font-semibold text-slate-900">{usersPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={usersPercentage} className="h-3" />
            </div>
            {usersPercentage >= 90 && (
              <p className="text-xs text-red-600 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" />
                Limite quase atingido!
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Installations (Informative) */}
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-base flex items-center gap-2">
            <Building2 className="w-5 h-5 text-green-600" />
            Instalações
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            <div className="flex items-end justify-between">
              <div>
                <p className="text-3xl font-bold text-slate-900">{currentInstallations}</p>
                <p className="text-sm text-slate-500">Total registadas</p>
              </div>
              <TrendingUp className="w-4 h-4 text-green-600" />
            </div>
            <div className="space-y-2">
              <p className="text-xs text-slate-500">
                Sem limite de instalações
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}