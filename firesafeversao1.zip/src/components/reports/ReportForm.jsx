import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Save, X, Plus, Trash2, Upload, CheckCircle2, XCircle, Camera, Image as ImageIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

// Função para comprimir imagem
async function compressImage(file, maxSizeMB = 1, maxWidthOrHeight = 1920) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target.result;
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        // Redimensionar se necessário
        if (width > height) {
          if (width > maxWidthOrHeight) {
            height *= maxWidthOrHeight / width;
            width = maxWidthOrHeight;
          }
        } else {
          if (height > maxWidthOrHeight) {
            width *= maxWidthOrHeight / height;
            height = maxWidthOrHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;

        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);

        // Tentar diferentes qualidades até atingir o tamanho desejado
        let quality = 0.9;
        const tryCompress = () => {
          canvas.toBlob(
            (blob) => {
              if (blob.size > maxSizeMB * 1024 * 1024 && quality > 0.1) {
                quality -= 0.1;
                tryCompress();
              } else {
                const compressedFile = new File([blob], file.name, {
                  type: 'image/jpeg',
                  lastModified: Date.now(),
                });
                console.log(`Imagem comprimida: ${(file.size / 1024 / 1024).toFixed(2)}MB → ${(blob.size / 1024 / 1024).toFixed(2)}MB`);
                resolve(compressedFile);
              }
            },
            'image/jpeg',
            quality
          );
        };
        tryCompress();
      };
      img.onerror = reject;
    };
    reader.onerror = reject;
  });
}

export default function ReportForm({ maintenance, technicians, equipment = [], onSubmit, onCancel, isLoading }) {
  const { data: templates = [] } = useQuery({
    queryKey: ['checklist-templates'],
    queryFn: () => base44.entities.ChecklistTemplate.list(),
  });

  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [formData, setFormData] = useState({
    maintenance_id: maintenance?.id || "",
    report_number: `REL-${new Date().getFullYear()}-${String(Math.floor(Math.random() * 1000)).padStart(3, '0')}`,
    date: new Date().toISOString().split('T')[0],
    technician_id: maintenance?.technician_id || "",
    en54_checklist: {},
    equipment_tested: [],
    defects_found: [],
    conclusion: "approved",
    recommendations: "",
    next_inspection_date: "",
    certificate_issued: false,
    photos: []
  });

  useEffect(() => {
    const defaultTemplate = templates.find(t => t.is_default && t.status === 'active') || 
                           templates.find(t => t.status === 'active');
    
    if (defaultTemplate && !selectedTemplate) {
      setSelectedTemplate(defaultTemplate);
      
      const initialChecklist = {};
      defaultTemplate.items?.forEach(item => {
        initialChecklist[item.key] = false;
      });
      
      setFormData(prev => ({ ...prev, en54_checklist: initialChecklist }));
    }
  }, [templates, selectedTemplate]);

  const handleTemplateChange = (templateId) => {
    const template = templates.find(t => t.id === templateId);
    setSelectedTemplate(template);
    
    const initialChecklist = {};
    template?.items?.forEach(item => {
      initialChecklist[item.key] = false;
    });
    
    setFormData(prev => ({ ...prev, en54_checklist: initialChecklist }));
  };

  const [newEquipment, setNewEquipment] = useState({
    equipment_id: "",
    status: "approved",
    observations: ""
  });

  const [newDefect, setNewDefect] = useState({
    description: "",
    severity: "moderate",
    action_required: ""
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleChecklistChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      en54_checklist: { ...prev.en54_checklist, [field]: value }
    }));
  };

  const addEquipment = () => {
    if (!newEquipment.equipment_id) return;
    setFormData(prev => ({
      ...prev,
      equipment_tested: [...prev.equipment_tested, { ...newEquipment }]
    }));
    setNewEquipment({ equipment_id: "", status: "approved", observations: "" });
  };

  const removeEquipment = (index) => {
    setFormData(prev => ({
      ...prev,
      equipment_tested: prev.equipment_tested.filter((_, i) => i !== index)
    }));
  };

  const addDefect = () => {
    if (!newDefect.description) return;
    setFormData(prev => ({
      ...prev,
      defects_found: [...prev.defects_found, { ...newDefect }]
    }));
    setNewDefect({ description: "", severity: "moderate", action_required: "" });
  };

  const removeDefect = (index) => {
    setFormData(prev => ({
      ...prev,
      defects_found: prev.defects_found.filter((_, i) => i !== index)
    }));
  };

  // Funções para fotos COM COMPRESSÃO
  const handlePhotoUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setUploadingPhoto(true);
    try {
      const uploadedUrls = [];
      
      for (let i = 0; i < files.length; i++) {
        const file = files[i];
        
        // Comprimir imagem antes de enviar
        console.log(`Comprimindo imagem ${i + 1}...`);
        const compressedFile = await compressImage(file, 1, 1920); // Max 1MB, Max 1920px
        
        const result = await base44.integrations.Core.UploadFile({ file: compressedFile });
        if (result.file_url) {
          uploadedUrls.push(result.file_url);
        }
      }

      setFormData(prev => ({
        ...prev,
        photos: [...prev.photos, ...uploadedUrls]
      }));
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      alert('Erro ao fazer upload das fotos. Tente novamente.');
    } finally {
      setUploadingPhoto(false);
      e.target.value = '';
    }
  };

  const handleCameraCapture = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploadingPhoto(true);
    try {
      // Comprimir imagem da câmera
      console.log('Comprimindo foto da câmera...');
      const compressedFile = await compressImage(file, 1, 1920);
      
      const result = await base44.integrations.Core.UploadFile({ file: compressedFile });
      if (result.file_url) {
        setFormData(prev => ({
          ...prev,
          photos: [...prev.photos, result.file_url]
        }));
      }
    } catch (error) {
      console.error('Erro ao fazer upload:', error);
      alert('Erro ao fazer upload da foto. Tente novamente.');
    } finally {
      setUploadingPhoto(false);
      e.target.value = '';
    }
  };

  const removePhoto = (index) => {
    setFormData(prev => ({
      ...prev,
      photos: prev.photos.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const allChecked = selectedTemplate && Object.values(formData.en54_checklist).every(v => v === true);
  const activeTemplates = templates.filter(t => t.status === 'active');

  const getCategoryColor = (category) => {
    const colors = {
      inspection: 'text-blue-600',
      testing: 'text-green-600',
      documentation: 'text-purple-600',
      equipment: 'text-orange-600',
      safety: 'text-red-600'
    };
    return colors[category] || 'text-slate-600';
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle>Novo Relatório de Inspeção</CardTitle>
          {allChecked && (
            <Badge className="bg-green-100 text-green-800">
              <CheckCircle2 className="w-3 h-3 mr-1" />
              Checklist Completa
            </Badge>
          )}
        </div>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-6">
          {/* Basic Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label htmlFor="report_number">Número do Relatório *</Label>
              <Input
                id="report_number"
                value={formData.report_number}
                onChange={(e) => handleChange('report_number', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="date">Data *</Label>
              <Input
                id="date"
                type="date"
                value={formData.date}
                onChange={(e) => handleChange('date', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="technician_id">Técnico *</Label>
              <Select value={formData.technician_id} onValueChange={(value) => handleChange('technician_id', value)} required>
                <SelectTrigger>
                  <SelectValue placeholder="Selecionar técnico" />
                </SelectTrigger>
                <SelectContent>
                  {technicians.map(tech => (
                    <SelectItem key={tech.id} value={tech.id}>{tech.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Template Selection */}
          <div className="space-y-2">
            <Label htmlFor="template">Template de Checklist</Label>
            <Select 
              value={selectedTemplate?.id || ''} 
              onValueChange={handleTemplateChange}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecionar template" />
              </SelectTrigger>
              <SelectContent>
                {activeTemplates.map(template => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name} ({template.standard}) - {template.items?.length || 0} itens
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Checklist */}
          {selectedTemplate && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-slate-900">
                  Checklist {selectedTemplate.standard}
                </h3>
                <span className="text-sm text-slate-500">
                  {Object.values(formData.en54_checklist).filter(v => v).length} / {selectedTemplate.items?.length || 0}
                </span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
                {selectedTemplate.items?.map((item) => (
                  <div key={item.key} className="flex items-start gap-3">
                    <Checkbox
                      id={item.key}
                      checked={formData.en54_checklist[item.key] || false}
                      onCheckedChange={(checked) => handleChecklistChange(item.key, checked)}
                    />
                    <div className="flex-1">
                      <Label htmlFor={item.key} className="cursor-pointer text-sm">
                        {item.label}
                        {item.required && <span className="text-red-600 ml-1">*</span>}
                      </Label>
                      <div className="flex items-center gap-1 mt-1">
                        <Badge variant="outline" className={`text-xs ${getCategoryColor(item.category)}`}>
                          {item.category}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Equipment Tested */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">Equipamentos Testados</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg">
              <div className="space-y-2">
                <Label htmlFor="equipment_id">Equipamento</Label>
                <Select value={newEquipment.equipment_id} onValueChange={(value) => setNewEquipment({...newEquipment, equipment_id: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecionar" />
                  </SelectTrigger>
                  <SelectContent>
                    {equipment.map(eq => (
                      <SelectItem key={eq.id} value={eq.id}>
                        {eq.type} - {eq.model || eq.location}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="eq_status">Status</Label>
                <Select value={newEquipment.status} onValueChange={(value) => setNewEquipment({...newEquipment, status: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="approved">Aprovado</SelectItem>
                    <SelectItem value="needs_repair">Necessita Reparação</SelectItem>
                    <SelectItem value="needs_replacement">Necessita Substituição</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="eq_obs">Observações</Label>
                <div className="flex gap-2">
                  <Input
                    id="eq_obs"
                    value={newEquipment.observations}
                    onChange={(e) => setNewEquipment({...newEquipment, observations: e.target.value})}
                    placeholder="Observações..."
                  />
                  <Button type="button" onClick={addEquipment} size="icon" className="shrink-0">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>

            {formData.equipment_tested.length > 0 && (
              <div className="space-y-2">
                {formData.equipment_tested.map((eq, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-white border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-sm">
                          {equipment.find(e => e.id === eq.equipment_id)?.type || 'Equipamento'}
                        </span>
                        <Badge className={
                          eq.status === 'approved' ? 'bg-green-100 text-green-800' :
                          eq.status === 'needs_repair' ? 'bg-orange-100 text-orange-800' :
                          'bg-red-100 text-red-800'
                        }>
                          {eq.status === 'approved' ? 'Aprovado' :
                           eq.status === 'needs_repair' ? 'Reparação' : 'Substituição'}
                        </Badge>
                      </div>
                      {eq.observations && (
                        <p className="text-xs text-slate-600 mt-1">{eq.observations}</p>
                      )}
                    </div>
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeEquipment(index)}>
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Defects Found */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">Defeitos Encontrados</h3>
            
            <div className="grid grid-cols-1 gap-4 p-4 bg-orange-50 rounded-lg">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="defect_desc">Descrição</Label>
                  <Input
                    id="defect_desc"
                    value={newDefect.description}
                    onChange={(e) => setNewDefect({...newDefect, description: e.target.value})}
                    placeholder="Descrição do defeito..."
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="severity">Gravidade</Label>
                  <Select value={newDefect.severity} onValueChange={(value) => setNewDefect({...newDefect, severity: value})}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="minor">Menor</SelectItem>
                      <SelectItem value="moderate">Moderada</SelectItem>
                      <SelectItem value="critical">Crítica</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="action">Ação Necessária</Label>
                  <div className="flex gap-2">
                    <Input
                      id="action"
                      value={newDefect.action_required}
                      onChange={(e) => setNewDefect({...newDefect, action_required: e.target.value})}
                      placeholder="Ação..."
                    />
                    <Button type="button" onClick={addDefect} size="icon" className="shrink-0">
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {formData.defects_found.length > 0 && (
              <div className="space-y-2">
                {formData.defects_found.map((defect, index) => (
                  <div key={index} className="flex items-start justify-between p-3 bg-white border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className={
                          defect.severity === 'critical' ? 'border-red-500 text-red-700' :
                          defect.severity === 'moderate' ? 'border-orange-500 text-orange-700' :
                          'border-blue-500 text-blue-700'
                        }>
                          {defect.severity === 'critical' ? 'Crítica' :
                           defect.severity === 'moderate' ? 'Moderada' : 'Menor'}
                        </Badge>
                        <span className="text-sm font-medium">{defect.description}</span>
                      </div>
                      <p className="text-xs text-slate-600">Ação: {defect.action_required}</p>
                    </div>
                    <Button type="button" variant="ghost" size="icon" onClick={() => removeDefect(index)}>
                      <Trash2 className="w-4 h-4 text-red-600" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* FOTOS COM COMPRESSÃO AUTOMÁTICA */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-slate-900">📸 Fotografias da Inspeção</h3>
              {formData.photos.length > 0 && (
                <Badge variant="outline">{formData.photos.length} foto{formData.photos.length !== 1 ? 's' : ''}</Badge>
              )}
            </div>
            
            <div className="flex gap-3">
              {/* Upload de Fotos */}
              <div className="flex-1">
                <input
                  type="file"
                  id="photo-upload"
                  accept="image/*"
                  multiple
                  onChange={handlePhotoUpload}
                  className="hidden"
                  disabled={uploadingPhoto}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('photo-upload').click()}
                  disabled={uploadingPhoto}
                  className="w-full"
                >
                  <ImageIcon className="w-4 h-4 mr-2" />
                  {uploadingPhoto ? 'A carregar...' : 'Escolher Fotos'}
                </Button>
              </div>

              {/* Tirar Foto com Câmera */}
              <div className="flex-1">
                <input
                  type="file"
                  id="camera-capture"
                  accept="image/*"
                  capture="environment"
                  onChange={handleCameraCapture}
                  className="hidden"
                  disabled={uploadingPhoto}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => document.getElementById('camera-capture').click()}
                  disabled={uploadingPhoto}
                  className="w-full"
                >
                  <Camera className="w-4 h-4 mr-2" />
                  {uploadingPhoto ? 'A carregar...' : 'Tirar Foto'}
                </Button>
              </div>
            </div>

            {uploadingPhoto && (
              <div className="text-center py-4 bg-blue-50 rounded-lg border border-blue-200">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <p className="text-sm text-blue-700 mt-2 font-medium">Comprimindo e enviando foto...</p>
                <p className="text-xs text-blue-600 mt-1">Isto pode levar alguns segundos</p>
              </div>
            )}

            {/* Grid de Fotos */}
            {formData.photos.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {formData.photos.map((photoUrl, index) => (
                  <div key={index} className="relative group">
                    <img
                      src={photoUrl}
                      alt={`Foto ${index + 1}`}
                      className="w-full h-32 object-cover rounded-lg border-2 border-slate-200 hover:border-blue-400 transition-colors"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      onClick={() => removePhoto(index)}
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-8 w-8"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
                      Foto {index + 1}
                    </div>
                  </div>
                ))}
              </div>
            )}

            {formData.photos.length === 0 && !uploadingPhoto && (
              <div className="text-center py-8 bg-slate-50 rounded-lg border-2 border-dashed border-slate-300">
                <Camera className="w-12 h-12 text-slate-400 mx-auto mb-2" />
                <p className="text-sm text-slate-600 font-medium">Nenhuma foto adicionada</p>
                <p className="text-xs text-slate-500 mt-1">Tire fotos ou escolha da galeria</p>
                <p className="text-xs text-slate-400 mt-2">✨ Compressão automática ativa</p>
              </div>
            )}
          </div>

          {/* Conclusion */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="conclusion">Conclusão *</Label>
              <Select value={formData.conclusion} onValueChange={(value) => handleChange('conclusion', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="approved">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-green-600" />
                      Aprovado
                    </div>
                  </SelectItem>
                  <SelectItem value="approved_with_observations">
                    <div className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-yellow-600" />
                      Aprovado com Observações
                    </div>
                  </SelectItem>
                  <SelectItem value="not_approved">
                    <div className="flex items-center gap-2">
                      <XCircle className="w-4 h-4 text-red-600" />
                      Não Aprovado
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="next_inspection">Próxima Inspeção *</Label>
              <Input
                id="next_inspection"
                type="date"
                value={formData.next_inspection_date}
                onChange={(e) => handleChange('next_inspection_date', e.target.value)}
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="recommendations">Recomendações</Label>
            <Textarea
              id="recommendations"
              value={formData.recommendations}
              onChange={(e) => handleChange('recommendations', e.target.value)}
              rows={4}
              placeholder="Escreva as recomendações para o cliente..."
            />
          </div>

          <div className="flex items-center gap-2 p-4 bg-blue-50 rounded-lg">
            <Checkbox
              id="certificate_issued"
              checked={formData.certificate_issued}
              onCheckedChange={(checked) => handleChange('certificate_issued', checked)}
            />
            <Label htmlFor="certificate_issued" className="cursor-pointer">
              Emitir certificado de conformidade
            </Label>
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button type="submit" disabled={isLoading} className="bg-emerald-600 hover:bg-emerald-700">
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? 'A guardar...' : 'Guardar Relatório'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}