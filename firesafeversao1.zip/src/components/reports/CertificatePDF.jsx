import React from "react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { CheckCircle2, Award, Shield } from "lucide-react";

export default function CertificatePDF({ report, maintenance, installation, client, technician }) {
  return (
    <div className="bg-white p-12 max-w-4xl mx-auto min-h-screen flex flex-col" id="certificate-pdf">
      {/* Decorative Border */}
      <div className="border-8 border-double border-red-600 p-12 flex-1 flex flex-col">
        
        {/* Header with Logo */}
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-20 h-20 bg-gradient-to-br from-red-500 to-orange-600 rounded-full flex items-center justify-center">
              <Shield className="w-12 h-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-slate-900 mb-2">FireSafe Pro</h1>
          <p className="text-slate-600 text-lg">Sistema de Gestão de Segurança contra Incêndios</p>
        </div>

        {/* Certificate Title */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-4">
            <Award className="w-16 h-16 text-red-600" />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-4">
            CERTIFICADO DE CONFORMIDADE
          </h2>
          <p className="text-xl text-slate-700">
            Norma Europeia EN 54
          </p>
          <p className="text-lg text-slate-600 mt-2">
            Sistemas de Deteção e Alarme de Incêndio
          </p>
        </div>

        {/* Certificate Content */}
        <div className="flex-1 space-y-6">
          <div className="text-center text-lg text-slate-700 leading-relaxed">
            <p className="mb-4">Certifica-se que a instalação</p>
            
            <div className="bg-slate-50 p-6 rounded-lg border-2 border-slate-300 my-6">
              <p className="text-2xl font-bold text-slate-900 mb-2">{installation?.name}</p>
              {installation?.address && <p className="text-slate-700">{installation.address}</p>}
              {installation?.city && <p className="text-slate-700">{installation.postal_code} {installation.city}</p>}
            </div>

            <p className="mb-4">pertencente a</p>

            <div className="bg-slate-50 p-4 rounded-lg border-2 border-slate-300 my-6">
              <p className="text-xl font-bold text-slate-900">{client?.name}</p>
              {client?.company && <p className="text-slate-700">{client.company}</p>}
            </div>

            <p className="mb-6">
              foi inspecionada e testada em conformidade com os requisitos da norma EN 54,
              tendo sido verificado o correto funcionamento de todos os sistemas de deteção
              e alarme de incêndio.
            </p>
          </div>

          {/* Approval Badge */}
          <div className="flex justify-center my-8">
            <div className="bg-green-100 border-4 border-green-600 rounded-full p-8">
              <CheckCircle2 className="w-24 h-24 text-green-600" />
            </div>
          </div>

          <div className="text-center">
            <div className="inline-block bg-green-600 text-white px-8 py-4 rounded-lg">
              <p className="text-2xl font-bold">SISTEMA APROVADO</p>
            </div>
          </div>
        </div>

        {/* Certificate Details */}
        <div className="grid grid-cols-2 gap-6 mt-12 pt-8 border-t-2 border-slate-300">
          <div>
            <p className="text-sm text-slate-600 mb-1">Número do Certificado</p>
            <p className="font-bold text-slate-900 text-lg">{report.report_number}</p>
          </div>
          <div>
            <p className="text-sm text-slate-600 mb-1">Data de Emissão</p>
            <p className="font-bold text-slate-900 text-lg">
              {format(new Date(report.date), "dd/MM/yyyy", { locale: pt })}
            </p>
          </div>
          <div>
            <p className="text-sm text-slate-600 mb-1">Validade do Certificado</p>
            <p className="font-bold text-slate-900 text-lg">
              {format(new Date(report.next_inspection_date), "dd/MM/yyyy", { locale: pt })}
            </p>
          </div>
          <div>
            <p className="text-sm text-slate-600 mb-1">Técnico Certificado</p>
            <p className="font-bold text-slate-900">{technician?.name}</p>
            {technician?.certification_number && (
              <p className="text-sm text-slate-600">Cert: {technician.certification_number}</p>
            )}
          </div>
        </div>

        {/* Signature */}
        <div className="text-center mt-12 pt-8 border-t-2 border-slate-300">
          <div className="inline-block">
            <div className="border-t-2 border-slate-900 pt-2 mt-16 min-w-[300px]">
              <p className="font-bold text-slate-900 text-lg">{technician?.name}</p>
              <p className="text-sm text-slate-600">Técnico Certificado EN 54</p>
              {technician?.certification_number && (
                <p className="text-xs text-slate-500">Certificação: {technician.certification_number}</p>
              )}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="text-center text-xs text-slate-500 mt-8">
          <p className="mb-1">Este certificado atesta a conformidade do sistema na data da inspeção</p>
          <p>Válido até {format(new Date(report.next_inspection_date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}</p>
        </div>
      </div>
    </div>
  );
}

export function printCertificate() {
  window.print();
}