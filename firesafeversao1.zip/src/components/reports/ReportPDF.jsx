import React from "react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import { CheckCircle2, XCircle, AlertTriangle } from "lucide-react";

export default function ReportPDF({ report, maintenance, installation, client, technician, equipment }) {
  const checklistLabels = {
    visual_inspection: "Inspeção visual completa",
    functional_test: "Teste funcional",
    alarm_test: "Teste de alarme",
    battery_test: "Teste de baterias",
    detector_sensitivity: "Sensibilidade dos detectores",
    signaling_devices: "Dispositivos de sinalização",
    control_panel: "Painel de controlo",
    emergency_power: "Alimentação de emergência",
    documentation_updated: "Documentação atualizada"
  };

  const getConclusionLabel = (conclusion) => {
    const labels = {
      approved: 'APROVADO',
      approved_with_observations: 'APROVADO COM OBSERVAÇÕES',
      not_approved: 'NÃO APROVADO'
    };
    return labels[conclusion] || conclusion;
  };

  return (
    <div className="bg-white p-12 max-w-4xl mx-auto" id="report-pdf">
      {/* Header */}
      <div className="border-b-4 border-red-600 pb-6 mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 mb-2">FireSafe Pro</h1>
            <p className="text-slate-600">Sistema de Gestão de Segurança contra Incêndios</p>
          </div>
          <div className="text-right">
            <div className="text-sm text-slate-600">Relatório Nº</div>
            <div className="text-2xl font-bold text-red-600">{report.report_number}</div>
          </div>
        </div>
      </div>

      {/* Report Title */}
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">
          RELATÓRIO DE INSPEÇÃO E MANUTENÇÃO
        </h2>
        <h3 className="text-xl font-semibold text-slate-700">
          Conforme Norma EN 54
        </h3>
      </div>

      {/* Client Info */}
      <div className="grid grid-cols-2 gap-6 mb-8 p-6 bg-slate-50 rounded-lg">
        <div>
          <p className="text-sm text-slate-600 mb-1">Cliente</p>
          <p className="font-semibold text-slate-900">{client?.name}</p>
          {client?.company && <p className="text-sm text-slate-700">{client.company}</p>}
        </div>
        <div>
          <p className="text-sm text-slate-600 mb-1">Instalação</p>
          <p className="font-semibold text-slate-900">{installation?.name}</p>
          {installation?.address && <p className="text-sm text-slate-700">{installation.address}</p>}
          {installation?.city && <p className="text-sm text-slate-700">{installation.postal_code} {installation.city}</p>}
        </div>
        <div>
          <p className="text-sm text-slate-600 mb-1">Data da Inspeção</p>
          <p className="font-semibold text-slate-900">
            {format(new Date(report.date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
          </p>
        </div>
        <div>
          <p className="text-sm text-slate-600 mb-1">Técnico Responsável</p>
          <p className="font-semibold text-slate-900">{technician?.name}</p>
          {technician?.certification_number && (
            <p className="text-sm text-slate-700">Cert: {technician.certification_number}</p>
          )}
        </div>
      </div>

      {/* EN54 Checklist */}
      <div className="mb-8">
        <h3 className="text-lg font-bold text-slate-900 mb-4 border-b-2 border-slate-300 pb-2">
          CHECKLIST DE CONFORMIDADE EN54
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(checklistLabels).map(([key, label]) => (
            <div key={key} className="flex items-center gap-3 p-2 bg-slate-50 rounded">
              {report.en54_checklist?.[key] ? (
                <CheckCircle2 className="w-5 h-5 text-green-600 flex-shrink-0" />
              ) : (
                <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              )}
              <span className="text-sm text-slate-700">{label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Equipment Tested */}
      {report.equipment_tested && report.equipment_tested.length > 0 && (
        <div className="mb-8">
          <h3 className="text-lg font-bold text-slate-900 mb-4 border-b-2 border-slate-300 pb-2">
            EQUIPAMENTOS TESTADOS
          </h3>
          <table className="w-full border-collapse">
            <thead>
              <tr className="bg-slate-100">
                <th className="border border-slate-300 p-2 text-left text-sm">Equipamento</th>
                <th className="border border-slate-300 p-2 text-left text-sm">Status</th>
                <th className="border border-slate-300 p-2 text-left text-sm">Observações</th>
              </tr>
            </thead>
            <tbody>
              {report.equipment_tested.map((eq, index) => {
                const equipmentItem = equipment.find(e => e.id === eq.equipment_id);
                return (
                  <tr key={index}>
                    <td className="border border-slate-300 p-2 text-sm">
                      {equipmentItem?.type} - {equipmentItem?.model || equipmentItem?.location}
                    </td>
                    <td className="border border-slate-300 p-2 text-sm">
                      <span className={`font-semibold ${
                        eq.status === 'approved' ? 'text-green-700' :
                        eq.status === 'needs_repair' ? 'text-orange-700' :
                        'text-red-700'
                      }`}>
                        {eq.status === 'approved' ? 'Aprovado' :
                         eq.status === 'needs_repair' ? 'Reparação Necessária' :
                         'Substituição Necessária'}
                      </span>
                    </td>
                    <td className="border border-slate-300 p-2 text-sm">{eq.observations || '-'}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Defects Found */}
      {report.defects_found && report.defects_found.length > 0 && (
        <div className="mb-8">
          <h3 className="text-lg font-bold text-slate-900 mb-4 border-b-2 border-slate-300 pb-2">
            DEFEITOS E NÃO CONFORMIDADES ENCONTRADAS
          </h3>
          <div className="space-y-3">
            {report.defects_found.map((defect, index) => (
              <div key={index} className="border-l-4 border-orange-500 bg-orange-50 p-3">
                <div className="flex items-center gap-2 mb-2">
                  <span className={`px-2 py-1 text-xs font-semibold rounded ${
                    defect.severity === 'critical' ? 'bg-red-200 text-red-900' :
                    defect.severity === 'moderate' ? 'bg-orange-200 text-orange-900' :
                    'bg-blue-200 text-blue-900'
                  }`}>
                    {defect.severity === 'critical' ? 'CRÍTICA' :
                     defect.severity === 'moderate' ? 'MODERADA' : 'MENOR'}
                  </span>
                  <span className="font-semibold text-sm">{defect.description}</span>
                </div>
                <p className="text-sm text-slate-700">
                  <strong>Ação Necessária:</strong> {defect.action_required}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* FOTOGRAFIAS - SEÇÃO COMPLETA */}
      {report.photos && report.photos.length > 0 && (
        <div className="mb-8 page-break-before">
          <h3 className="text-lg font-bold text-slate-900 mb-4 border-b-2 border-slate-300 pb-2">
            REGISTO FOTOGRÁFICO DA INSPEÇÃO
          </h3>
          <div className="grid grid-cols-2 gap-4">
            {report.photos.map((photoUrl, index) => (
              <div key={index} className="border border-slate-300 rounded overflow-hidden">
                <img
                  src={photoUrl}
                  alt={`Foto da inspeção ${index + 1}`}
                  className="w-full h-48 object-cover"
                  onError={(e) => {
                    e.target.style.display = 'none';
                    const parent = e.target.parentElement;
                    const placeholder = parent.querySelector('.photo-placeholder');
                    if (placeholder) {
                      placeholder.style.display = 'flex';
                    }
                  }}
                />
                <div className="photo-placeholder hidden items-center justify-center h-48 bg-slate-100 text-slate-500 text-sm">
                  Imagem não disponível
                </div>
                <div className="bg-slate-50 p-2 text-center">
                  <p className="text-xs text-slate-600 font-semibold">
                    Fotografia {index + 1}
                  </p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-slate-500 mt-4 italic">
            {report.photos.length} fotografia{report.photos.length !== 1 ? 's' : ''} anexada{report.photos.length !== 1 ? 's' : ''} como evidência da inspeção realizada.
          </p>
        </div>
      )}

      {/* Recommendations */}
      {report.recommendations && (
        <div className="mb-8">
          <h3 className="text-lg font-bold text-slate-900 mb-4 border-b-2 border-slate-300 pb-2">
            RECOMENDAÇÕES
          </h3>
          <div className="bg-blue-50 p-4 rounded border-l-4 border-blue-500">
            <p className="text-sm text-slate-700 whitespace-pre-line">{report.recommendations}</p>
          </div>
        </div>
      )}

      {/* Conclusion */}
      <div className="mb-8">
        <h3 className="text-lg font-bold text-slate-900 mb-4 border-b-2 border-slate-300 pb-2">
          CONCLUSÃO
        </h3>
        <div className={`p-6 rounded-lg text-center ${
          report.conclusion === 'approved' ? 'bg-green-100 border-2 border-green-600' :
          report.conclusion === 'approved_with_observations' ? 'bg-yellow-100 border-2 border-yellow-600' :
          'bg-red-100 border-2 border-red-600'
        }`}>
          <p className={`text-2xl font-bold ${
            report.conclusion === 'approved' ? 'text-green-900' :
            report.conclusion === 'approved_with_observations' ? 'text-yellow-900' :
            'text-red-900'
          }`}>
            {getConclusionLabel(report.conclusion)}
          </p>
        </div>
      </div>

      {/* Next Inspection */}
      <div className="mb-8">
        <div className="bg-slate-100 p-4 rounded">
          <p className="text-sm text-slate-700">
            <strong>Próxima Inspeção Recomendada:</strong>{' '}
            {format(new Date(report.next_inspection_date), "dd 'de' MMMM 'de' yyyy", { locale: pt })}
          </p>
        </div>
      </div>

      {/* Signatures */}
      <div className="grid grid-cols-2 gap-12 mt-12 pt-8 border-t-2 border-slate-300">
        <div className="text-center">
          <div className="border-t-2 border-slate-400 pt-2 mt-16">
            <p className="font-semibold text-slate-900">{technician?.name}</p>
            <p className="text-sm text-slate-600">Técnico Responsável</p>
            {technician?.certification_number && (
              <p className="text-xs text-slate-500">Cert: {technician.certification_number}</p>
            )}
          </div>
        </div>
        <div className="text-center">
          <div className="border-t-2 border-slate-400 pt-2 mt-16">
            <p className="font-semibold text-slate-900">{client?.name}</p>
            <p className="text-sm text-slate-600">Cliente</p>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="mt-12 pt-6 border-t border-slate-300 text-center text-xs text-slate-500">
        <p>FireSafe Pro - Sistema de Gestão de Segurança contra Incêndios</p>
        <p>Este relatório é válido apenas com assinatura do técnico responsável</p>
        <p className="mt-1">Documento gerado em {format(new Date(), "dd/MM/yyyy 'às' HH:mm", { locale: pt })}</p>
      </div>

      <style>{`
        @media print {
          .page-break-before {
            page-break-before: always;
          }
        }
      `}</style>
    </div>
  );
}

export function printReport() {
  window.print();
}