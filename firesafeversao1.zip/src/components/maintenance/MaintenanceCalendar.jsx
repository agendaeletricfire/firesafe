import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isSameDay, addMonths, subMonths } from "date-fns";
import { pt } from "date-fns/locale";

export default function MaintenanceCalendar({ maintenances, installations, technicians, onSelectMaintenance }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getMaintenancesForDay = (day) => {
    return maintenances.filter(m => isSameDay(new Date(m.scheduled_date), day));
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'scheduled': return 'bg-blue-500';
      case 'in_progress': return 'bg-orange-500';
      case 'completed': return 'bg-green-500';
      default: return 'bg-slate-500';
    }
  };

  const previousMonth = () => setCurrentMonth(subMonths(currentMonth, 1));
  const nextMonth = () => setCurrentMonth(addMonths(currentMonth, 1));

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-orange-600" />
            {format(currentMonth, "MMMM yyyy", { locale: pt })}
          </CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="icon" onClick={previousMonth}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <Button variant="outline" size="icon" onClick={nextMonth}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-7 gap-2">
          {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
            <div key={day} className="text-center font-semibold text-sm text-slate-600 py-2">
              {day}
            </div>
          ))}
          
          {Array(monthStart.getDay()).fill(null).map((_, i) => (
            <div key={`empty-${i}`} className="min-h-24 bg-slate-50 rounded-lg" />
          ))}
          
          {daysInMonth.map(day => {
            const dayMaintenances = getMaintenancesForDay(day);
            const isToday = isSameDay(day, new Date());
            
            return (
              <div 
                key={day.toISOString()}
                className={`min-h-24 p-2 border rounded-lg ${
                  isToday ? 'border-orange-500 bg-orange-50' : 'border-slate-200 bg-white'
                } hover:shadow-md transition-shadow`}
              >
                <div className="font-semibold text-sm mb-2">
                  {format(day, 'd')}
                </div>
                <div className="space-y-1">
                  {dayMaintenances.slice(0, 3).map(maintenance => {
                    const installation = installations.find(i => i.id === maintenance.installation_id);
                    return (
                      <button
                        key={maintenance.id}
                        onClick={() => onSelectMaintenance(maintenance)}
                        className={`w-full text-left px-2 py-1 rounded text-xs ${getStatusColor(maintenance.status)} text-white hover:opacity-80 transition-opacity truncate`}
                      >
                        {maintenance.scheduled_time} {installation?.name}
                      </button>
                    );
                  })}
                  {dayMaintenances.length > 3 && (
                    <div className="text-xs text-slate-500 text-center">
                      +{dayMaintenances.length - 3} mais
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-6 flex gap-4 justify-center">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-blue-500 rounded"></div>
            <span className="text-sm text-slate-600">Agendada</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-orange-500 rounded"></div>
            <span className="text-sm text-slate-600">Em Progresso</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-green-500 rounded"></div>
            <span className="text-sm text-slate-600">Concluída</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}