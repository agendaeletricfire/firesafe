import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  X, 
  Edit, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  Lock,
  Users,
  Shield
} from "lucide-react";

const MODULES = [
  { id: 'dashboard', name: 'Dashboard' },
  { id: 'clients', name: 'Clientes' },
  { id: 'installations', name: 'Instalações' },
  { id: 'equipment', name: 'Equipamentos' },
  { id: 'maintenance', name: 'Manutenções' },
  { id: 'reports', name: 'Relatórios' },
  { id: 'technicians', name: 'Técnicos' },
  { id: 'checklists', name: 'Checklists' },
  { id: 'users', name: 'Usuários' },
  { id: 'licensing', name: 'Licenciamento' },
  { id: 'settings', name: 'Configurações' },
];

const PERMISSION_LABELS = {
  view: 'Ver',
  create: 'Criar',
  edit: 'Editar',
  delete: 'Eliminar'
};

export default function RoleDetails({ role, userCount, onClose, onEdit, onDelete }) {
  const hasAnyPermission = (modulePerms) => {
    return Object.values(modulePerms || {}).some(p => p === true);
  };

  const getActivePermissions = (modulePerms) => {
    return Object.entries(modulePerms || {})
      .filter(([_, value]) => value === true)
      .map(([key]) => PERMISSION_LABELS[key] || key);
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5 text-indigo-600" />
            Detalhes da Função
          </CardTitle>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="p-6 space-y-6">
        {/* Role Info */}
        <div>
          <div className="flex items-center gap-3 mb-2">
            <h3 className="text-2xl font-bold text-slate-900">{role.name}</h3>
            <Badge className={role.is_active ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
              {role.is_active ? 'Ativa' : 'Inativa'}
            </Badge>
            {role.is_system_role && (
              <Badge className="bg-slate-100 text-slate-800">
                <Lock className="w-3 h-3 mr-1" />
                Sistema
              </Badge>
            )}
          </div>
          {role.description && (
            <p className="text-slate-600">{role.description}</p>
          )}
        </div>

        {/* User Count */}
        <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-600" />
              <span className="font-semibold text-purple-900">Usuários com esta função:</span>
            </div>
            <span className="text-2xl font-bold text-purple-900">{userCount}</span>
          </div>
        </div>

        {/* System Role Warning */}
        {role.is_system_role && (
          <Alert className="border-orange-200 bg-orange-50">
            <AlertTriangle className="w-4 h-4 text-orange-600" />
            <AlertDescription className="text-orange-900">
              <strong>Função do Sistema:</strong> Esta função não pode ser eliminada pois faz parte do sistema base.
            </AlertDescription>
          </Alert>
        )}

        {/* Permissions */}
        <div className="space-y-4">
          <h4 className="font-semibold text-slate-900 text-lg">Permissões Configuradas</h4>
          
          <div className="space-y-3">
            {MODULES.map((module) => {
              const modulePerms = role.permissions?.[module.id];
              const hasPerms = hasAnyPermission(modulePerms);
              const activePerms = getActivePermissions(modulePerms);

              return (
                <Card key={module.id} className="border border-slate-200">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h5 className="font-semibold text-slate-900 mb-2">{module.name}</h5>
                        {hasPerms ? (
                          <div className="flex flex-wrap gap-2">
                            {activePerms.map((perm) => (
                              <Badge key={perm} className="bg-green-100 text-green-800">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                {perm}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <Badge className="bg-slate-100 text-slate-600">
                            <XCircle className="w-3 h-3 mr-1" />
                            Sem permissões
                          </Badge>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </CardContent>
      <CardFooter className="border-t border-slate-100 flex justify-between">
        <div>
          {!role.is_system_role && (
            <Button 
              variant="outline" 
              className="text-red-600 hover:text-red-700 hover:bg-red-50"
              onClick={() => onDelete(role.id)}
            >
              <Trash2 className="w-4 h-4 mr-2" />
              Eliminar
            </Button>
          )}
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={onClose}>
            Fechar
          </Button>
          <Button 
            onClick={() => onEdit(role)}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            <Edit className="w-4 h-4 mr-2" />
            Editar
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}