import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Save, X, Info, CheckCircle2 } from "lucide-react";

const MODULES = [
  { id: 'dashboard', name: 'Dashboard', permissions: ['view'] },
  { id: 'clients', name: 'Clientes', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'installations', name: 'Instalações', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'equipment', name: 'Equipamentos', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'maintenance', name: 'Manutenções', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'reports', name: 'Relatórios', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'technicians', name: 'Técnicos', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'checklists', name: 'Checklists', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'users', name: 'Usuários', permissions: ['view', 'create', 'edit', 'delete'] },
  { id: 'licensing', name: 'Licenciamento', permissions: ['view', 'edit'] },
  { id: 'settings', name: 'Configurações', permissions: ['view', 'edit'] },
];

const PERMISSION_LABELS = {
  view: 'Ver',
  create: 'Criar',
  edit: 'Editar',
  delete: 'Eliminar'
};

export default function RoleForm({ role, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(role || {
    name: "",
    description: "",
    is_active: true,
    permissions: MODULES.reduce((acc, module) => {
      acc[module.id] = module.permissions.reduce((perms, perm) => {
        perms[perm] = false;
        return perms;
      }, {});
      return acc;
    }, {})
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handlePermissionChange = (moduleId, permission, checked) => {
    setFormData(prev => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [moduleId]: {
          ...prev.permissions[moduleId],
          [permission]: checked
        }
      }
    }));
  };

  const handleSelectAll = (moduleId) => {
    const module = MODULES.find(m => m.id === moduleId);
    const allSelected = module.permissions.every(p => formData.permissions[moduleId][p]);
    
    setFormData(prev => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [moduleId]: module.permissions.reduce((acc, perm) => {
          acc[perm] = !allSelected;
          return acc;
        }, {})
      }
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const countActivePermissions = () => {
    let count = 0;
    Object.values(formData.permissions).forEach(module => {
      Object.values(module).forEach(perm => {
        if (perm) count++;
      });
    });
    return count;
  };

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle>{role ? 'Editar Função' : 'Nova Função'}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-6">
          {/* Info Alert */}
          <Alert className="border-blue-200 bg-blue-50">
            <Info className="w-4 h-4 text-blue-600" />
            <AlertDescription className="text-blue-900 text-sm">
              <strong>Dica:</strong> Defina permissões específicas para cada módulo. 
              Por exemplo: Técnicos podem ver e criar manutenções, mas não eliminar.
            </AlertDescription>
          </Alert>

          {/* Basic Info */}
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome da Função *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                placeholder="Ex: Gerente de Operações, Técnico de Campo"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Descrição</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Descreva as responsabilidades desta função..."
                rows={3}
              />
            </div>
            <div className="flex items-center gap-2">
              <Checkbox
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => handleChange('is_active', checked)}
              />
              <Label htmlFor="is_active" className="cursor-pointer">
                Função ativa (usuários podem usar esta função)
              </Label>
            </div>
          </div>

          {/* Permissions Summary */}
          <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-200">
            <div className="flex items-center justify-between">
              <span className="text-sm font-semibold text-indigo-900">
                Total de Permissões Ativas:
              </span>
              <Badge className="bg-indigo-600 text-white">
                <CheckCircle2 className="w-3 h-3 mr-1" />
                {countActivePermissions()}
              </Badge>
            </div>
          </div>

          {/* Permissions */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-slate-900">Permissões por Módulo</h3>
            
            <div className="space-y-4">
              {MODULES.map((module) => (
                <Card key={module.id} className="border border-slate-200">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{module.name}</CardTitle>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleSelectAll(module.id)}
                        className="text-xs"
                      >
                        {module.permissions.every(p => formData.permissions[module.id][p]) 
                          ? 'Desmarcar Todas' 
                          : 'Selecionar Todas'}
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {module.permissions.map((permission) => (
                        <div key={permission} className="flex items-center gap-2">
                          <Checkbox
                            id={`${module.id}-${permission}`}
                            checked={formData.permissions[module.id][permission]}
                            onCheckedChange={(checked) => 
                              handlePermissionChange(module.id, permission, checked)
                            }
                          />
                          <Label 
                            htmlFor={`${module.id}-${permission}`}
                            className="cursor-pointer text-sm"
                          >
                            {PERMISSION_LABELS[permission]}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button 
            type="submit" 
            disabled={isLoading}
            className="bg-indigo-600 hover:bg-indigo-700"
          >
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? 'A guardar...' : 'Guardar'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}

function Badge({ children, className }) {
  return (
    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${className}`}>
      {children}
    </span>
  );
}