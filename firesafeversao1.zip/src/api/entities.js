import { base44 } from './base44Client';


export const License = base44.entities.License;

export const Client = base44.entities.Client;

export const Installation = base44.entities.Installation;

export const Equipment = base44.entities.Equipment;

export const Technician = base44.entities.Technician;

export const Maintenance = base44.entities.Maintenance;

export const MaintenanceReport = base44.entities.MaintenanceReport;

export const ChecklistTemplate = base44.entities.ChecklistTemplate;

export const EmailConfig = base44.entities.EmailConfig;

export const Role = base44.entities.Role;

export const WhatsAppConfig = base44.entities.WhatsAppConfig;



// auth sdk:
export const User = base44.auth;