import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Users as UsersIcon, 
  Search, 
  Shield, 
  User,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  UserPlus,
  Info
} from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import UserDetails from "../components/users/UserDetails";
import UserCreateForm from "../components/users/UserCreateForm";

export default function UsersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterRole, setFilterRole] = useState("all");
  const [selectedUser, setSelectedUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
      } catch (error) {
        console.error("Error fetching user:", error);
      }
    };
    fetchCurrentUser();
  }, []);

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list('-created_date'),
  });

  const { data: licenses = [] } = useQuery({
    queryKey: ['licenses'],
    queryFn: () => base44.entities.License.list(),
  });

  const { data: roles = [] } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list(),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.User.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
      setSelectedUser(null);
    },
  });

  const handleUpdate = (id, data) => {
    updateMutation.mutate({ id, data });
  };

  const handleCreateUser = async (userData, method) => {
    console.log("Processing user creation:", userData, method);
    
    if (method === 'direct') {
      // Show alert with manual instructions
      const roleInfo = userData.role === 'admin' ? 'Administrador (acesso total)' : 'Usuário';
      const customRoleInfo = userData.custom_role_id ? 
        `\n- Função: ${roles.find(r => r.id === userData.custom_role_id)?.name}` : '';
      
      alert(`
✅ CRIAR USUÁRIO MANUALMENTE

Por favor, siga estes passos:

1️⃣ ACEDA AO DASHBOARD BASE44
   → dashboard.base44.com

2️⃣ NAVEGUE PARA "INVITE USERS"
   
3️⃣ PREENCHA OS DADOS:
   - Email: ${userData.email}
   - Nome: ${userData.full_name}
   - Tipo: ${roleInfo}${customRoleInfo}

4️⃣ ENVIE O CONVITE
   O usuário receberá email com link de ativação

5️⃣ APÓS ATIVAÇÃO
   O usuário aparecerá automaticamente nesta lista
   Pode então configurar as permissões aqui

💡 NOTA: Por questões de segurança, novos usuários devem 
ser convidados através do sistema oficial do Base44.
      `.trim());
      
      setShowCreateForm(false);
    } else {
      // Invite method
      const roleInfo = userData.role === 'admin' ? 'Administrador (acesso total)' : 'Usuário';
      const customRoleInfo = userData.custom_role_id ? 
        `\n- Função: ${roles.find(r => r.id === userData.custom_role_id)?.name}` : '';
      
      alert(`
📧 ENVIAR CONVITE POR EMAIL

1️⃣ ACEDA AO DASHBOARD BASE44
   → dashboard.base44.com

2️⃣ NAVEGUE PARA "INVITE USERS"

3️⃣ PREENCHA:
   - Email: ${userData.email}
   - Nome: ${userData.full_name}
   - Tipo: ${roleInfo}${customRoleInfo}

4️⃣ ENVIE O CONVITE
   ${userData.full_name} receberá email com link de ativação

Após aceitar o convite, pode configurar as permissões aqui.
      `.trim());
      
      setShowCreateForm(false);
    }
  };

  // Get active license
  const activeLicense = licenses.find(l => l.status === 'active');
  const usersLimit = activeLicense?.max_users || 999;
  const usersPercentage = (users.length / usersLimit) * 100;

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         u.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === "all" || u.role === filterRole;
    return matchesSearch && matchesRole;
  });

  const adminCount = users.filter(u => u.role === 'admin').length;
  const userCount = users.filter(u => u.role === 'user').length;
  const customRoleCount = users.filter(u => u.custom_role_id).length;

  const getUserRole = (user) => {
    return roles.find(r => r.id === user.custom_role_id);
  };

  // Loading state
  if (!currentUser) {
    return (
      <div className="p-6 lg:p-8 flex items-center justify-center">
        <p className="text-slate-500">A carregar...</p>
      </div>
    );
  }

  // Only admins can access
  if (currentUser.role !== 'admin') {
    return (
      <div className="p-6 lg:p-8">
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-900">
            <strong>⛔ Acesso Negado</strong><br/>
            Esta página está restrita apenas a administradores.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <UsersIcon className="w-8 h-8 text-purple-600" />
            Gestão de Usuários
          </h1>
          <p className="text-slate-500 mt-1">Gerir equipa e permissões</p>
        </div>
        
        <Button 
          onClick={() => setShowCreateForm(true)}
          className="bg-purple-600 hover:bg-purple-700 text-white font-semibold px-6 py-3 shadow-lg hover:shadow-xl transition-all"
          size="lg"
        >
          <UserPlus className="w-5 h-5 mr-2" />
          Adicionar Usuário
        </Button>
      </div>

      {/* Info Alert */}
      <Alert className="border-blue-200 bg-blue-50">
        <Info className="w-5 h-5 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>Como adicionar usuários:</strong> Por questões de segurança, novos usuários devem ser convidados 
          através do Dashboard Base44. Clique em "Adicionar Usuário" para ver as instruções passo a passo.
        </AlertDescription>
      </Alert>

      {/* License Warning */}
      {usersPercentage >= 80 && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          <AlertDescription className="text-orange-900">
            <strong>Limite de usuários próximo!</strong> {users.length} de {usersLimit} usuários utilizados ({usersPercentage.toFixed(0)}%).
          </AlertDescription>
        </Alert>
      )}

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Total de Usuários</CardTitle>
              <UsersIcon className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{users.length}</div>
            <p className="text-xs opacity-80 mt-1">de {usersLimit} permitidos</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Administradores</CardTitle>
              <Shield className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{adminCount}</div>
            <p className="text-xs opacity-80 mt-1">Acesso total</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Usuários</CardTitle>
              <User className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{userCount}</div>
            <p className="text-xs opacity-80 mt-1">Acesso limitado</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Com Funções</CardTitle>
              <Shield className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{customRoleCount}</div>
            <p className="text-xs opacity-80 mt-1">Funções personalizadas</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Pesquisar por nome ou email..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <div className="flex gap-2">
          <Button
            variant={filterRole === "all" ? "default" : "outline"}
            onClick={() => setFilterRole("all")}
            size="sm"
          >
            Todos
          </Button>
          <Button
            variant={filterRole === "admin" ? "default" : "outline"}
            onClick={() => setFilterRole("admin")}
            size="sm"
          >
            <Shield className="w-3 h-3 mr-2" />
            Admins
          </Button>
          <Button
            variant={filterRole === "user" ? "default" : "outline"}
            onClick={() => setFilterRole("user")}
            size="sm"
          >
            <User className="w-3 h-3 mr-2" />
            Users
          </Button>
        </div>
      </div>

      {/* Create Form */}
      {showCreateForm && (
        <UserCreateForm
          roles={roles}
          onSubmit={handleCreateUser}
          onCancel={() => setShowCreateForm(false)}
          isLoading={false}
        />
      )}

      {/* User Details */}
      {selectedUser && !showCreateForm && (
        <UserDetails
          user={selectedUser}
          currentUser={currentUser}
          onClose={() => setSelectedUser(null)}
          onUpdate={handleUpdate}
        />
      )}

      {/* Users List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="animate-pulse border-none shadow-md">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                <div className="h-3 bg-slate-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-slate-200 rounded"></div>
                  <div className="h-3 bg-slate-200 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : filteredUsers.length > 0 ? (
          filteredUsers.map((user) => {
            const customRole = getUserRole(user);
            
            return (
              <Card 
                key={user.id}
                className="border-none shadow-md hover:shadow-lg transition-all cursor-pointer"
                onClick={() => setSelectedUser(user)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3 flex-1">
                      <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-lg">
                        {user.full_name?.[0]?.toUpperCase() || 'U'}
                      </div>
                      <div className="flex-1 min-w-0">
                        <CardTitle className="text-lg text-slate-900 truncate">{user.full_name}</CardTitle>
                        <p className="text-sm text-slate-500 truncate">{user.email}</p>
                      </div>
                    </div>
                    <div className="flex flex-col gap-1">
                      <Badge className={user.role === 'admin' ? 'bg-blue-100 text-blue-800' : 'bg-slate-100 text-slate-800'}>
                        {user.role === 'admin' ? (
                          <><Shield className="w-3 h-3 mr-1" />Admin</>
                        ) : (
                          <><User className="w-3 h-3 mr-1" />User</>
                        )}
                      </Badge>
                      {customRole && (
                        <Badge className="bg-indigo-100 text-indigo-800 text-xs">
                          {customRole.name}
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-slate-600">
                    <Calendar className="w-4 h-4" />
                    <span>Desde {format(new Date(user.created_date), "dd/MM/yyyy")}</span>
                  </div>
                  {user.id === currentUser.id && (
                    <Badge className="bg-green-100 text-green-800 text-xs">
                      <CheckCircle2 className="w-3 h-3 mr-1" />
                      Você
                    </Badge>
                  )}
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="col-span-full text-center py-12">
            <UsersIcon className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">Nenhum usuário encontrado</p>
          </div>
        )}
      </div>
    </div>
  );
}