import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Key, 
  Plus, 
  Edit, 
  AlertTriangle, 
  CheckCircle2, 
  Clock,
  Users,
  Building2,
  TrendingUp,
  Shield,
  Calendar,
  XCircle
} from "lucide-react";
import { format, differenceInDays, isBefore, isAfter } from "date-fns";
import { pt } from "date-fns/locale";
import LicenseForm from "../components/licensing/LicenseForm";
import UsageMetrics from "../components/licensing/UsageMetrics";

export default function Licensing() {
  const [showForm, setShowForm] = useState(false);
  const [editingLicense, setEditingLicense] = useState(null);
  const [user, setUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  const { data: licenses = [], isLoading } = useQuery({
    queryKey: ['licenses'],
    queryFn: () => base44.entities.License.list('-created_date'),
  });

  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
  });

  const { data: installations = [] } = useQuery({
    queryKey: ['installations'],
    queryFn: () => base44.entities.Installation.list(),
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.License.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['licenses'] });
      setShowForm(false);
      setEditingLicense(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.License.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['licenses'] });
      setShowForm(false);
      setEditingLicense(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingLicense) {
      updateMutation.mutate({ id: editingLicense.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  // Get active license
  const activeLicense = licenses.find(l => 
    l.status === 'active' && 
    isBefore(new Date(), new Date(l.end_date))
  );

  // Check if license is expiring soon (30 days)
  const isExpiringSoon = activeLicense && 
    differenceInDays(new Date(activeLicense.end_date), new Date()) <= 30;

  const daysUntilExpiry = activeLicense ? 
    differenceInDays(new Date(activeLicense.end_date), new Date()) : 0;

  // Calculate usage percentages
  const clientsUsage = activeLicense ? (clients.length / activeLicense.max_clients) * 100 : 0;
  const usersUsage = activeLicense ? (users.length / activeLicense.max_users) * 100 : 0;

  const getStatusColor = (status) => {
    switch(status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'expired': return 'bg-red-100 text-red-800';
      case 'suspended': return 'bg-orange-100 text-orange-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getStatusIcon = (status) => {
    switch(status) {
      case 'active': return <CheckCircle2 className="w-4 h-4" />;
      case 'expired': return <XCircle className="w-4 h-4" />;
      case 'suspended': return <AlertTriangle className="w-4 h-4" />;
      default: return null;
    }
  };

  const getStatusLabel = (status) => {
    const labels = {
      active: 'Ativa',
      expired: 'Expirada',
      suspended: 'Suspensa'
    };
    return labels[status] || status;
  };

  if (!user) return null;

  // Only admins can access
  if (user.role !== 'admin') {
    return (
      <div className="p-6 lg:p-8">
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-900">
            Acesso restrito apenas a administradores
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Key className="w-8 h-8 text-blue-600" />
            Gestão de Licenciamento
          </h1>
          <p className="text-slate-500 mt-1">Controlo de licenças e limites do sistema</p>
        </div>
        <Button 
          onClick={() => {
            setEditingLicense(null);
            setShowForm(true);
          }}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nova Licença
        </Button>
      </div>

      {/* Alerts */}
      {!activeLicense && (
        <Alert className="border-red-200 bg-red-50">
          <XCircle className="w-5 h-5 text-red-600" />
          <AlertDescription className="text-red-900">
            <strong>Sem licença ativa!</strong> O sistema está a funcionar sem licença válida. Crie ou renove uma licença.
          </AlertDescription>
        </Alert>
      )}

      {activeLicense && isExpiringSoon && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          <AlertDescription className="text-orange-900">
            <strong>Licença a expirar em {daysUntilExpiry} dias!</strong> A licença expira em {format(new Date(activeLicense.end_date), "dd 'de' MMMM, yyyy", { locale: pt })}. Renove antes da data limite.
          </AlertDescription>
        </Alert>
      )}

      {activeLicense && (clientsUsage > 90 || usersUsage > 90) && (
        <Alert className="border-orange-200 bg-orange-50">
          <AlertTriangle className="w-5 h-5 text-orange-600" />
          <AlertDescription className="text-orange-900">
            <strong>Limites próximos do máximo!</strong> Considere aumentar os limites da licença.
          </AlertDescription>
        </Alert>
      )}

      {/* Active License Card */}
      {activeLicense && (
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardHeader className="border-b border-blue-100">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-6 h-6 text-blue-600" />
                Licença Ativa
              </CardTitle>
              <Badge className={getStatusColor(activeLicense.status)}>
                {getStatusIcon(activeLicense.status)}
                <span className="ml-1">{getStatusLabel(activeLicense.status)}</span>
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <p className="text-sm text-slate-600 mb-1">Empresa</p>
                <p className="text-xl font-bold text-slate-900">{activeLicense.company_name}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Código da Licença</p>
                <p className="text-lg font-mono font-semibold text-blue-700">{activeLicense.code}</p>
              </div>
              <div>
                <p className="text-sm text-slate-600 mb-1">Validade</p>
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-slate-600" />
                  <span className="font-semibold text-slate-900">
                    {format(new Date(activeLicense.end_date), "dd/MM/yyyy")}
                  </span>
                  <Badge variant="outline" className={daysUntilExpiry <= 30 ? 'border-orange-500 text-orange-700' : ''}>
                    {daysUntilExpiry} dias
                  </Badge>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-6 border-t border-blue-100">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-blue-100">
                  <div>
                    <p className="text-sm text-slate-600 mb-1">Período</p>
                    <p className="text-sm font-medium text-slate-900">
                      {format(new Date(activeLicense.start_date), "dd/MM/yyyy")} - {format(new Date(activeLicense.end_date), "dd/MM/yyyy")}
                    </p>
                  </div>
                  <Clock className="w-8 h-8 text-blue-600" />
                </div>
                <div className="flex items-center justify-end gap-2">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setEditingLicense(activeLicense);
                      setShowForm(true);
                    }}
                  >
                    <Edit className="w-4 h-4 mr-2" />
                    Editar Licença
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Usage Metrics */}
      {activeLicense && (
        <UsageMetrics
          license={activeLicense}
          currentClients={clients.length}
          currentUsers={users.length}
          currentInstallations={installations.length}
        />
      )}

      {/* License Form */}
      {showForm && (
        <LicenseForm
          license={editingLicense}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingLicense(null);
          }}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />
      )}

      {/* License History */}
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-slate-600" />
            Histórico de Licenças
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-3">
              {Array(3).fill(0).map((_, i) => (
                <div key={i} className="animate-pulse flex items-center gap-4 p-4 bg-slate-50 rounded-lg">
                  <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                  <div className="h-4 bg-slate-200 rounded w-1/2"></div>
                  <div className="h-4 bg-slate-200 rounded w-1/4"></div>
                </div>
              ))}
            </div>
          ) : licenses.length > 0 ? (
            <div className="space-y-3">
              {licenses.map((license) => (
                <div 
                  key={license.id}
                  className="flex flex-col md:flex-row md:items-center justify-between gap-4 p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <p className="font-semibold text-slate-900">{license.company_name}</p>
                      <Badge className={getStatusColor(license.status)}>
                        {getStatusIcon(license.status)}
                        <span className="ml-1">{getStatusLabel(license.status)}</span>
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600">
                      Código: <span className="font-mono font-semibold">{license.code}</span>
                    </p>
                    <p className="text-sm text-slate-600">
                      {format(new Date(license.start_date), "dd/MM/yyyy")} - {format(new Date(license.end_date), "dd/MM/yyyy")}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className="text-xs text-slate-500">Limites</p>
                      <p className="text-sm font-medium text-slate-700">
                        {license.max_users} usuários • {license.max_clients} clientes
                      </p>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setEditingLicense(license);
                        setShowForm(true);
                      }}
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Key className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">Nenhuma licença registada</p>
              <p className="text-sm text-slate-400 mt-2">
                Crie uma licença para começar
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}