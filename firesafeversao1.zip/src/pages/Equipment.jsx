
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Wrench, Plus, Search, AlertTriangle, CheckCircle2, Clock } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import EquipmentForm from "../components/equipment/EquipmentForm";
import EquipmentCard from "../components/equipment/EquipmentCard";
import PermissionGuard, { usePermissions } from "../components/shared/PermissionGuard";

export default function Equipment() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingEquipment, setEditingEquipment] = useState(null);
  const queryClient = useQueryClient();

  // Permission check
  const { canView, canCreate, canEdit, canDelete } = usePermissions('equipment');

  const { data: equipment = [], isLoading } = useQuery({
    queryKey: ['equipment'],
    queryFn: () => base44.entities.Equipment.list('-created_date'),
  });

  const { data: installations = [] } = useQuery({
    queryKey: ['installations'],
    queryFn: () => base44.entities.Installation.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Equipment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['equipment'] });
      setShowForm(false);
      setEditingEquipment(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Equipment.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['equipment'] });
      setShowForm(false);
      setEditingEquipment(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingEquipment) {
      updateMutation.mutate({ id: editingEquipment.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredEquipment = equipment.filter(eq => {
    const matchesSearch = eq.model?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         eq.manufacturer?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         eq.location?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || eq.type === filterType;
    const matchesStatus = filterStatus === "all" || eq.status === filterStatus;
    return matchesSearch && matchesType && matchesStatus;
  });

  const statusCounts = {
    operational: equipment.filter(e => e.status === 'operational').length,
    needs_maintenance: equipment.filter(e => e.status === 'needs_maintenance').length,
    needs_replacement: equipment.filter(e => e.status === 'needs_replacement').length,
    out_of_service: equipment.filter(e => e.status === 'out_of_service').length,
  };

  return (
    <PermissionGuard module="equipment" action="view">
      <div className="p-6 lg:p-8 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Wrench className="w-8 h-8 text-green-600" />
              Equipamentos
            </h1>
            <p className="text-slate-500 mt-1">Gerir todos os equipamentos de incêndio</p>
          </div>
          {canCreate && (
            <Button 
              onClick={() => {
                setEditingEquipment(null);
                setShowForm(true);
              }}
              className="bg-green-600 hover:bg-green-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Equipamento
            </Button>
          )}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{statusCounts.operational}</p>
                  <p className="text-xs text-slate-500">Operacionais</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{statusCounts.needs_maintenance}</p>
                  <p className="text-xs text-slate-500">Manutenção</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
                  <AlertTriangle className="w-5 h-5 text-red-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{statusCounts.needs_replacement}</p>
                  <p className="text-xs text-slate-500">Substituição</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center">
                  <Wrench className="w-5 h-5 text-slate-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{equipment.length}</p>
                  <p className="text-xs text-slate-500">Total</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Pesquisar equipamentos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Tipo" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os tipos</SelectItem>
              <SelectItem value="extinguisher">Extintores</SelectItem>
              <SelectItem value="fire_alarm">Alarmes</SelectItem>
              <SelectItem value="smoke_detector">Detectores</SelectItem>
              <SelectItem value="sprinkler">Sprinklers</SelectItem>
              <SelectItem value="fire_hose">Mangueiras</SelectItem>
              <SelectItem value="emergency_lighting">Iluminação</SelectItem>
              <SelectItem value="fire_door">Portas</SelectItem>
              <SelectItem value="control_panel">Painéis</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os status</SelectItem>
              <SelectItem value="operational">Operacional</SelectItem>
              <SelectItem value="needs_maintenance">Necessita Manutenção</SelectItem>
              <SelectItem value="needs_replacement">Necessita Substituição</SelectItem>
              <SelectItem value="out_of_service">Fora de Serviço</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {showForm && canCreate && (
          <EquipmentForm
            equipment={editingEquipment}
            installations={installations}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingEquipment(null);
            }}
            isLoading={createMutation.isPending || updateMutation.isPending}
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader className="space-y-2">
                  <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-slate-200 rounded"></div>
                    <div className="h-3 bg-slate-200 rounded w-5/6"></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredEquipment.length > 0 ? (
            filteredEquipment.map((eq) => (
              <EquipmentCard
                key={eq.id}
                equipment={eq}
                installations={installations}
                onEdit={canEdit ? (eq) => {
                  setEditingEquipment(eq);
                  setShowForm(true);
                } : null}
              />
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <Wrench className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">Nenhum equipamento encontrado</p>
            </div>
          )}
        </div>
      </div>
    </PermissionGuard>
  );
}
