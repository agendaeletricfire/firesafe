
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Plus, Search, Clock, CheckCircle2, AlertCircle, FileText } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import MaintenanceForm from "../components/maintenance/MaintenanceForm";
import MaintenanceCalendar from "../components/maintenance/MaintenanceCalendar";
import PermissionGuard, { usePermissions } from "../components/shared/PermissionGuard";

export default function Maintenance() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [viewMode, setViewMode] = useState("list");
  const [showForm, setShowForm] = useState(false);
  const [editingMaintenance, setEditingMaintenance] = useState(null);
  const queryClient = useQueryClient();

  // Permission check
  const { canView, canCreate, canEdit, canDelete } = usePermissions('maintenance');

  const { data: maintenances = [], isLoading } = useQuery({
    queryKey: ['maintenances'],
    queryFn: () => base44.entities.Maintenance.list('-scheduled_date'),
  });

  const { data: installations = [] } = useQuery({
    queryKey: ['installations'],
    queryFn: () => base44.entities.Installation.list(),
  });

  const { data: technicians = [] } = useQuery({
    queryKey: ['technicians'],
    queryFn: () => base44.entities.Technician.list(),
  });

  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
  });

  const { data: reports = [] } = useQuery({
    queryKey: ['reports'],
    queryFn: () => base44.entities.MaintenanceReport.list(),
  });

  const createMutation = useMutation({
    mutationFn: async (data) => {
      const maintenance = await base44.entities.Maintenance.create(data);
      
      if (data.notify_client && data.installation_id) {
        const installation = installations.find(i => i.id === data.installation_id);
        const client = clients.find(c => c.id === installation?.client_id);
        
        if (client?.email) {
          await base44.integrations.Core.SendEmail({
            to: client.email,
            subject: '🔥 Manutenção Agendada - Sistema de Incêndio',
            body: `
Olá ${client.name},

Foi agendada uma manutenção para a instalação "${installation.name}".

📅 Data: ${format(new Date(data.scheduled_date), "dd 'de' MMMM, yyyy", { locale: pt })}
⏰ Hora: ${data.scheduled_time || 'A confirmar'}
🔧 Tipo: ${data.type?.replace(/_/g, ' ')}

Em caso de dúvidas, entre em contacto connosco.

Atenciosamente,
FireSafe Pro
            `
          });
        }
      }
      
      return maintenance;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maintenances'] });
      setShowForm(false);
      setEditingMaintenance(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Maintenance.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['maintenances'] });
      setShowForm(false);
      setEditingMaintenance(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingMaintenance) {
      updateMutation.mutate({ id: editingMaintenance.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredMaintenances = maintenances.filter(m => {
    const installation = installations.find(i => i.id === m.installation_id);
    const technician = technicians.find(t => t.id === m.technician_id);
    const matchesSearch = installation?.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         technician?.name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || m.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = {
    scheduled: maintenances.filter(m => m.status === 'scheduled').length,
    in_progress: maintenances.filter(m => m.status === 'in_progress').length,
    completed: maintenances.filter(m => m.status === 'completed').length,
  };

  const getStatusColor = (status) => {
    switch(status) {
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'in_progress': return 'bg-orange-100 text-orange-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'cancelled': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getStatusLabel = (status) => {
    const labels = {
      scheduled: 'Agendada',
      in_progress: 'Em Progresso',
      completed: 'Concluída',
      cancelled: 'Cancelada',
      rescheduled: 'Reagendada'
    };
    return labels[status] || status;
  };

  const getTypeLabel = (type) => {
    const types = {
      routine_inspection: 'Inspeção de Rotina',
      preventive: 'Preventiva',
      corrective: 'Corretiva',
      emergency: 'Emergência',
      certification: 'Certificação'
    };
    return types[type] || type;
  };

  const hasReport = (maintenanceId) => {
    return reports.some(r => r.maintenance_id === maintenanceId);
  };

  const handleCreateReport = (maintenance) => {
    window.location.href = `/Reports?maintenance_id=${maintenance.id}`;
  };

  return (
    <PermissionGuard module="maintenance" action="view">
      <div className="p-6 lg:p-8 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Calendar className="w-8 h-8 text-orange-600" />
              Manutenções
            </h1>
            <p className="text-slate-500 mt-1">Agendar e gerir manutenções</p>
          </div>
          <div className="flex gap-2">
            <Button 
              variant={viewMode === 'list' ? 'default' : 'outline'}
              onClick={() => setViewMode('list')}
            >
              Lista
            </Button>
            <Button 
              variant={viewMode === 'calendar' ? 'default' : 'outline'}
              onClick={() => setViewMode('calendar')}
            >
              Calendário
            </Button>
            {canCreate && (
              <Button 
                onClick={() => {
                  setEditingMaintenance(null);
                  setShowForm(true);
                }}
                className="bg-orange-600 hover:bg-orange-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Manutenção
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{statusCounts.scheduled}</p>
                  <p className="text-xs text-slate-500">Agendadas</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                  <AlertCircle className="w-5 h-5 text-orange-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{statusCounts.in_progress}</p>
                  <p className="text-xs text-slate-500">Em Progresso</p>
                </div>
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-md">
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle2 className="w-5 h-5 text-green-600" />
                </div>
                <div>
                  <p className="text-2xl font-bold text-slate-900">{statusCounts.completed}</p>
                  <p className="text-xs text-slate-500">Concluídas</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {viewMode === 'list' && (
          <>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                <Input
                  placeholder="Pesquisar manutenções..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="w-full md:w-48">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os status</SelectItem>
                  <SelectItem value="scheduled">Agendada</SelectItem>
                  <SelectItem value="in_progress">Em Progresso</SelectItem>
                  <SelectItem value="completed">Concluída</SelectItem>
                  <SelectItem value="cancelled">Cancelada</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {showForm && canCreate && (
              <MaintenanceForm
                maintenance={editingMaintenance}
                installations={installations}
                technicians={technicians}
                onSubmit={handleSubmit}
                onCancel={() => {
                  setShowForm(false);
                  setEditingMaintenance(null);
                }}
                isLoading={createMutation.isPending || updateMutation.isPending}
              />
            )}

            <div className="space-y-4">
              {isLoading ? (
                Array(5).fill(0).map((_, i) => (
                  <Card key={i} className="animate-pulse border-none shadow-md">
                    <CardContent className="p-6">
                      <div className="space-y-3">
                        <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                        <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                      </div>
                    </CardContent>
                  </Card>
                ))
              ) : filteredMaintenances.length > 0 ? (
                filteredMaintenances.map((maintenance) => {
                  const installation = installations.find(i => i.id === maintenance.installation_id);
                  const technician = technicians.find(t => t.id === maintenance.technician_id);
                  const reportExists = hasReport(maintenance.id);
                  
                  return (
                    <Card 
                      key={maintenance.id}
                      className="border-none shadow-md hover:shadow-lg transition-all"
                    >
                      <CardContent className="p-6">
                        <div className="flex flex-col gap-4">
                          <div className="flex flex-col md:flex-row justify-between gap-4">
                            <div 
                              className="flex-1 space-y-2 cursor-pointer"
                              onClick={canEdit ? () => {
                                setEditingMaintenance(maintenance);
                                setShowForm(true);
                              } : undefined}
                            >
                              <div className="flex items-center gap-2">
                                <h3 className="text-lg font-semibold text-slate-900">
                                  {installation?.name || 'Instalação não encontrada'}
                                </h3>
                                <Badge className={getStatusColor(maintenance.status)}>
                                  {getStatusLabel(maintenance.status)}
                                </Badge>
                                {reportExists && (
                                  <Badge className="bg-emerald-100 text-emerald-800">
                                    <FileText className="w-3 h-3 mr-1" />
                                    Com Relatório
                                  </Badge>
                                )}
                              </div>
                              <p className="text-sm text-slate-500">{getTypeLabel(maintenance.type)}</p>
                              {technician && (
                                <p className="text-sm text-slate-600">👷 {technician.name}</p>
                              )}
                            </div>
                            <div className="flex flex-col items-start md:items-end gap-1">
                              <div className="flex items-center gap-2 text-slate-900">
                                <Calendar className="w-4 h-4" />
                                <span className="font-medium">
                                  {format(new Date(maintenance.scheduled_date), "dd/MM/yyyy")}
                                </span>
                              </div>
                              {maintenance.scheduled_time && (
                                <div className="flex items-center gap-2 text-slate-600">
                                  <Clock className="w-4 h-4" />
                                  <span className="text-sm">{maintenance.scheduled_time}</span>
                                </div>
                              )}
                              {maintenance.priority && (
                                <Badge variant="outline" className="mt-1">
                                  Prioridade: {maintenance.priority}
                                </Badge>
                              )}
                            </div>
                          </div>
                          
                          {canCreate && maintenance.status === 'completed' && !reportExists && (
                            <div className="pt-3 border-t border-slate-200">
                              <Button 
                                onClick={() => handleCreateReport(maintenance)}
                                className="w-full bg-emerald-600 hover:bg-emerald-700"
                              >
                                <FileText className="w-4 h-4 mr-2" />
                                Criar Relatório de Inspeção EN54
                              </Button>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              ) : (
                <div className="text-center py-12">
                  <Calendar className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-500">Nenhuma manutenção encontrada</p>
                </div>
              )}
            </div>
          </>
        )}

        {viewMode === 'calendar' && (
          <MaintenanceCalendar 
            maintenances={maintenances}
            installations={installations}
            technicians={technicians}
            onSelectMaintenance={canEdit ? (m) => {
              setEditingMaintenance(m);
              setShowForm(true);
              setViewMode('list');
            } : null}
          />
        )}
      </div>
    </PermissionGuard>
  );
}
