import React, { useState, useEffect, useRef } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User,
  Smartphone,
  QrCode,
  CheckCircle2,
  AlertTriangle,
  Info,
  Loader2,
  ExternalLink,
  Sparkles,
  Plus,
  Trash2,
  Calendar,
  Search,
  Settings,
  Save,
  X
} from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";

export default function AIAssistant() {
  const [user, setUser] = useState(null);
  const [conversations, setConversations] = useState([]);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [activeTab, setActiveTab] = useState("chat");
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();

  const agentName = "firesafe_assistant";
  const whatsappURL = base44.agents.getWhatsAppConnectURL(agentName);

  // WhatsApp Config State
  const [configForm, setConfigForm] = useState({
    whatsapp_number: "",
    widget_enabled: true,
    welcome_message: "👋 Olá! Bem-vindo ao FireSafe Pro\n\nComo podemos ajudá-lo hoje?",
    quick_messages: [
      "Olá! Preciso de agendar uma manutenção 🔧",
      "Gostaria de informações sobre serviços 📋",
      "Tenho uma emergência! ⚠️",
      "Quero fazer uma consulta 💬"
    ],
    business_hours: {
      enabled: false,
      message: "Horário de atendimento: Seg-Sex, 9h-18h"
    },
    auto_reply_enabled: false,
    is_active: true
  });

  const [newQuickMessage, setNewQuickMessage] = useState("");

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  useEffect(() => {
    if (user) {
      loadConversations();
    }
  }, [user]);

  useEffect(() => {
    if (selectedConversation) {
      const unsubscribe = base44.agents.subscribeToConversation(
        selectedConversation.id,
        (data) => {
          setMessages(data.messages || []);
        }
      );

      return () => unsubscribe();
    }
  }, [selectedConversation]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Load WhatsApp Config
  const { data: configs = [] } = useQuery({
    queryKey: ['whatsapp-config'],
    queryFn: () => base44.entities.WhatsAppConfig.list(),
  });

  const activeConfig = configs.find(c => c.is_active) || {};

  useEffect(() => {
    if (activeConfig.id) {
      setConfigForm(activeConfig);
    }
  }, [activeConfig.id]);

  const saveConfigMutation = useMutation({
    mutationFn: async (data) => {
      if (activeConfig.id) {
        return await base44.entities.WhatsAppConfig.update(activeConfig.id, data);
      } else {
        return await base44.entities.WhatsAppConfig.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['whatsapp-config'] });
      alert("✅ Configurações guardadas com sucesso!");
    },
  });

  const handleConfigChange = (field, value) => {
    setConfigForm(prev => ({ ...prev, [field]: value }));
  };

  const handleBusinessHoursChange = (field, value) => {
    setConfigForm(prev => ({
      ...prev,
      business_hours: {
        ...prev.business_hours,
        [field]: value
      }
    }));
  };

  const addQuickMessage = () => {
    if (!newQuickMessage.trim()) return;
    setConfigForm(prev => ({
      ...prev,
      quick_messages: [...prev.quick_messages, newQuickMessage.trim()]
    }));
    setNewQuickMessage("");
  };

  const removeQuickMessage = (index) => {
    setConfigForm(prev => ({
      ...prev,
      quick_messages: prev.quick_messages.filter((_, i) => i !== index)
    }));
  };

  const handleSaveConfig = () => {
    saveConfigMutation.mutate(configForm);
  };

  const loadConversations = async () => {
    try {
      const convs = await base44.agents.listConversations({
        agent_name: agentName,
      });
      setConversations(convs || []);
      
      if (convs && convs.length > 0 && !selectedConversation) {
        const conv = await base44.agents.getConversation(convs[0].id);
        setSelectedConversation(conv);
        setMessages(conv.messages || []);
      }
    } catch (error) {
      console.error("Error loading conversations:", error);
    }
  };

  const createNewConversation = async () => {
    try {
      const conv = await base44.agents.createConversation({
        agent_name: agentName,
        metadata: {
          name: `Chat ${format(new Date(), "dd/MM/yyyy HH:mm", { locale: pt })}`,
          description: "Conversa com assistente FireSafe Pro",
        }
      });
      setSelectedConversation(conv);
      setMessages([]);
      setConversations([conv, ...conversations]);
    } catch (error) {
      console.error("Error creating conversation:", error);
    }
  };

  const deleteConversation = async (convId) => {
    if (!confirm("Tem certeza que deseja eliminar esta conversa?")) return;
    
    try {
      const updatedConvs = conversations.filter(c => c.id !== convId);
      setConversations(updatedConvs);
      
      if (selectedConversation?.id === convId) {
        if (updatedConvs.length > 0) {
          const conv = await base44.agents.getConversation(updatedConvs[0].id);
          setSelectedConversation(conv);
          setMessages(conv.messages || []);
        } else {
          setSelectedConversation(null);
          setMessages([]);
        }
      }
    } catch (error) {
      console.error("Error deleting conversation:", error);
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !selectedConversation || isSending) return;

    const messageText = inputMessage.trim();
    setInputMessage("");
    setIsSending(true);

    try {
      await base44.agents.addMessage(selectedConversation, {
        role: "user",
        content: messageText,
      });
    } catch (error) {
      console.error("Error sending message:", error);
    } finally {
      setIsSending(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const selectConversation = async (conv) => {
    try {
      const fullConv = await base44.agents.getConversation(conv.id);
      setSelectedConversation(fullConv);
      setMessages(fullConv.messages || []);
    } catch (error) {
      console.error("Error selecting conversation:", error);
    }
  };

  const filteredConversations = conversations.filter(conv => 
    conv.metadata?.name?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!user) return null;

  if (user.role !== 'admin') {
    return (
      <div className="p-6 lg:p-8">
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-900">
            Acesso restrito apenas a administradores
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <div className="bg-white border-b border-slate-200 p-4 shadow-sm flex-shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg">
              <Bot className="w-7 h-7 text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
                Assistente IA FireSafe Pro
                <Badge className="bg-purple-100 text-purple-800">
                  <Sparkles className="w-3 h-3 mr-1" />
                  WhatsApp
                </Badge>
              </h1>
              <p className="text-sm text-slate-500">Criação de manutenções via NIF, nome ou email</p>
            </div>
          </div>
          <a
            href={whatsappURL}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm font-medium"
          >
            <Smartphone className="w-4 h-4" />
            Conectar WhatsApp
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex-1 max-w-7xl mx-auto w-full p-6 overflow-hidden">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-2 mb-6">
            <TabsTrigger value="chat" className="flex items-center gap-2">
              <MessageCircle className="w-4 h-4" />
              Conversas
            </TabsTrigger>
            <TabsTrigger value="config" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Configurações WhatsApp
            </TabsTrigger>
          </TabsList>

          {/* Chat Tab */}
          <TabsContent value="chat" className="flex-1 flex gap-6 overflow-hidden mt-0">
            {/* Sidebar - Conversations List */}
            <Card className="w-80 border-none shadow-lg flex flex-col">
              <CardHeader className="border-b border-slate-100 pb-4">
                <div className="flex items-center justify-between mb-3">
                  <CardTitle className="text-base">Conversas</CardTitle>
                  <Button
                    size="sm"
                    onClick={createNewConversation}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Plus className="w-4 h-4 mr-1" />
                    Nova
                  </Button>
                </div>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
                  <Input
                    placeholder="Pesquisar..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-9 h-9 text-sm"
                  />
                </div>
              </CardHeader>
              <CardContent className="p-3 flex-1 overflow-y-auto">
                {filteredConversations.length > 0 ? (
                  <div className="space-y-2">
                    {filteredConversations.map((conv) => (
                      <div
                        key={conv.id}
                        className={`group p-3 rounded-lg cursor-pointer transition-all ${
                          selectedConversation?.id === conv.id
                            ? 'bg-purple-50 border-2 border-purple-200'
                            : 'bg-white hover:bg-slate-50 border border-slate-200'
                        }`}
                      >
                        <div 
                          onClick={() => selectConversation(conv)}
                          className="flex-1"
                        >
                          <div className="flex items-start justify-between">
                            <p className="font-medium text-sm text-slate-900 truncate flex-1">
                              {conv.metadata?.name || 'Conversa'}
                            </p>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-6 w-6 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={(e) => {
                                e.stopPropagation();
                                deleteConversation(conv.id);
                              }}
                            >
                              <Trash2 className="w-3 h-3 text-red-600" />
                            </Button>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            <p className="text-xs text-slate-500">
                              {format(new Date(conv.created_date), "dd MMM, HH:mm", { locale: pt })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : searchTerm ? (
                  <div className="text-center py-8">
                    <Search className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-sm text-slate-500">Nenhuma conversa encontrada</p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <MessageCircle className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-sm text-slate-500 mb-2">Nenhuma conversa ainda</p>
                    <Button
                      size="sm"
                      onClick={createNewConversation}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Iniciar Chat
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Chat Area */}
            <Card className="flex-1 border-none shadow-lg flex flex-col">
              {selectedConversation ? (
                <>
                  <CardHeader className="border-b border-slate-100 pb-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-lg">
                          {selectedConversation.metadata?.name || 'Conversa'}
                        </CardTitle>
                        <p className="text-sm text-slate-500 mt-1">
                          {messages.length} mensagens
                        </p>
                      </div>
                      <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        <Bot className="w-3 h-3 mr-1" />
                        Assistente Ativo
                      </Badge>
                    </div>
                  </CardHeader>

                  <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50">
                    {messages.length === 0 ? (
                      <div className="text-center py-12">
                        <Bot className="w-16 h-16 text-purple-300 mx-auto mb-4" />
                        <p className="text-slate-500 mb-4">Inicie uma conversa com o assistente</p>
                        <div className="space-y-2 text-sm text-slate-600 max-w-md mx-auto text-left bg-white p-4 rounded-lg border border-slate-200">
                          <p className="font-semibold text-slate-900 mb-2">💡 Exemplos de comandos:</p>
                          <p>• "Agendar manutenção para NIF 123456789"</p>
                          <p>• "Criar assistência para empresa XYZ Lda"</p>
                          <p>• "Marcar inspeção no cliente João Silva"</p>
                          <p>• "Consultar manutenções da instalação Hotel ABC"</p>
                          <p>• "Técnicos disponíveis para amanhã"</p>
                        </div>
                      </div>
                    ) : (
                      messages.map((msg, index) => (
                        <div
                          key={index}
                          className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                        >
                          {msg.role === 'assistant' && (
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center flex-shrink-0">
                              <Bot className="w-5 h-5 text-white" />
                            </div>
                          )}
                          <div
                            className={`max-w-[70%] rounded-2xl px-4 py-3 ${
                              msg.role === 'user'
                                ? 'bg-purple-600 text-white'
                                : 'bg-white border border-slate-200 text-slate-900'
                            }`}
                          >
                            <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                            
                            {msg.tool_calls && msg.tool_calls.length > 0 && (
                              <div className="mt-2 space-y-1">
                                {msg.tool_calls.map((tool, i) => (
                                  <div key={i} className="text-xs opacity-70 flex items-center gap-1">
                                    {tool.status === 'running' || tool.status === 'in_progress' ? (
                                      <Loader2 className="w-3 h-3 animate-spin" />
                                    ) : tool.status === 'completed' || tool.status === 'success' ? (
                                      <CheckCircle2 className="w-3 h-3" />
                                    ) : null}
                                    <span>{tool.name?.split('.').pop()}</span>
                                  </div>
                                ))}
                              </div>
                            )}
                          </div>
                          {msg.role === 'user' && (
                            <div className="w-8 h-8 rounded-full bg-slate-200 flex items-center justify-center flex-shrink-0">
                              <User className="w-5 h-5 text-slate-600" />
                            </div>
                          )}
                        </div>
                      ))
                    )}
                    <div ref={messagesEndRef} />
                  </div>

                  <div className="border-t border-slate-200 p-4 bg-white">
                    <div className="flex gap-2">
                      <Input
                        value={inputMessage}
                        onChange={(e) => setInputMessage(e.target.value)}
                        onKeyPress={handleKeyPress}
                        placeholder="Digite sua mensagem... (Ex: Agendar manutenção para NIF 123456789)"
                        disabled={isSending}
                        className="flex-1"
                      />
                      <Button
                        onClick={sendMessage}
                        disabled={!inputMessage.trim() || isSending}
                        className="bg-purple-600 hover:bg-purple-700"
                      >
                        {isSending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : (
                          <Send className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                </>
              ) : (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center">
                    <MessageCircle className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                    <p className="text-slate-500 mb-4">Selecione ou crie uma conversa</p>
                    <Button
                      onClick={createNewConversation}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Iniciar Nova Conversa
                    </Button>
                  </div>
                </div>
              )}
            </Card>
          </TabsContent>

          {/* Config Tab */}
          <TabsContent value="config" className="flex-1 overflow-y-auto mt-0">
            <div className="space-y-6">
              {/* Info Alert */}
              <Alert className="border-blue-200 bg-blue-50">
                <Info className="w-5 h-5 text-blue-600" />
                <AlertDescription className="text-blue-900">
                  <strong>Configure o Widget de WhatsApp</strong> que aparece no canto inferior direito 
                  de todas as páginas da aplicação. Estas configurações controlam como os clientes 
                  podem contactá-lo via WhatsApp.
                </AlertDescription>
              </Alert>

              {/* Main Config Card */}
              <Card className="border-none shadow-lg">
                <CardHeader className="border-b border-slate-100">
                  <CardTitle className="flex items-center gap-2">
                    <Smartphone className="w-5 h-5 text-green-600" />
                    Configurações do Widget WhatsApp
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-6 space-y-6">
                  {/* Widget Enabled */}
                  <div className="flex items-center gap-3 p-4 bg-slate-50 rounded-lg">
                    <Checkbox
                      id="widget_enabled"
                      checked={configForm.widget_enabled}
                      onCheckedChange={(checked) => handleConfigChange('widget_enabled', checked)}
                    />
                    <Label htmlFor="widget_enabled" className="cursor-pointer flex-1">
                      <p className="font-semibold text-slate-900">Ativar Widget de WhatsApp</p>
                      <p className="text-xs text-slate-500">Mostrar botão flutuante em todas as páginas</p>
                    </Label>
                  </div>

                  {/* WhatsApp Number */}
                  <div className="space-y-2">
                    <Label htmlFor="whatsapp_number">
                      Número do WhatsApp *
                      <span className="text-xs text-slate-500 ml-2">(Código país + número, sem espaços)</span>
                    </Label>
                    <Input
                      id="whatsapp_number"
                      value={configForm.whatsapp_number}
                      onChange={(e) => handleConfigChange('whatsapp_number', e.target.value)}
                      placeholder="351912345678"
                      className="font-mono"
                    />
                    <p className="text-xs text-slate-500">
                      Exemplo: Portugal +351 912 345 678 → <code className="bg-slate-100 px-1 rounded">351912345678</code>
                    </p>
                  </div>

                  {/* Welcome Message */}
                  <div className="space-y-2">
                    <Label htmlFor="welcome_message">Mensagem de Boas-Vindas</Label>
                    <Textarea
                      id="welcome_message"
                      value={configForm.welcome_message}
                      onChange={(e) => handleConfigChange('welcome_message', e.target.value)}
                      rows={3}
                      placeholder="👋 Olá! Bem-vindo ao FireSafe Pro..."
                    />
                  </div>

                  {/* Quick Messages */}
                  <div className="space-y-3">
                    <Label>Mensagens Rápidas</Label>
                    <div className="space-y-2">
                      {configForm.quick_messages.map((msg, index) => (
                        <div key={index} className="flex items-center gap-2">
                          <Input
                            value={msg}
                            onChange={(e) => {
                              const newMessages = [...configForm.quick_messages];
                              newMessages[index] = e.target.value;
                              handleConfigChange('quick_messages', newMessages);
                            }}
                            className="flex-1"
                          />
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeQuickMessage(index)}
                            className="text-red-600 hover:text-red-700"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                    <div className="flex gap-2">
                      <Input
                        value={newQuickMessage}
                        onChange={(e) => setNewQuickMessage(e.target.value)}
                        placeholder="Nova mensagem rápida..."
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault();
                            addQuickMessage();
                          }
                        }}
                      />
                      <Button
                        onClick={addQuickMessage}
                        disabled={!newQuickMessage.trim()}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Adicionar
                      </Button>
                    </div>
                  </div>

                  {/* Business Hours */}
                  <div className="space-y-3 p-4 bg-slate-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Checkbox
                        id="business_hours_enabled"
                        checked={configForm.business_hours.enabled}
                        onCheckedChange={(checked) => handleBusinessHoursChange('enabled', checked)}
                      />
                      <Label htmlFor="business_hours_enabled" className="cursor-pointer">
                        <p className="font-semibold text-slate-900">Mostrar Horário de Atendimento</p>
                      </Label>
                    </div>
                    {configForm.business_hours.enabled && (
                      <Input
                        value={configForm.business_hours.message}
                        onChange={(e) => handleBusinessHoursChange('message', e.target.value)}
                        placeholder="Horário de atendimento: Seg-Sex, 9h-18h"
                      />
                    )}
                  </div>

                  {/* Save Button */}
                  <div className="flex justify-end pt-4 border-t border-slate-200">
                    <Button
                      onClick={handleSaveConfig}
                      disabled={saveConfigMutation.isPending || !configForm.whatsapp_number}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {saveConfigMutation.isPending ? 'A guardar...' : 'Guardar Configurações'}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Preview Card */}
              <Card className="border-none shadow-lg bg-gradient-to-br from-green-50 to-emerald-50">
                <CardHeader>
                  <CardTitle className="text-base flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                    Pré-visualização do Widget
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-white rounded-lg p-4 border-2 border-green-200">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center">
                        <MessageCircle className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-bold text-slate-900">FireSafe Pro</p>
                        <p className="text-xs text-green-600">🟢 Online</p>
                      </div>
                    </div>
                    <div className="bg-green-50 rounded p-2 mb-3 text-sm">
                      {configForm.welcome_message}
                    </div>
                    {configForm.business_hours.enabled && (
                      <p className="text-xs text-slate-500 mb-2">
                        {configForm.business_hours.message}
                      </p>
                    )}
                    <div className="space-y-1">
                      {configForm.quick_messages.slice(0, 2).map((msg, i) => (
                        <div key={i} className="text-xs bg-white border rounded p-2">
                          {msg}
                        </div>
                      ))}
                      {configForm.quick_messages.length > 2 && (
                        <p className="text-xs text-slate-400">
                          +{configForm.quick_messages.length - 2} mais...
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}