import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { 
  Shield, 
  Plus, 
  Search, 
  Edit,
  Trash2,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Lock,
  Users
} from "lucide-react";
import RoleForm from "../components/roles/RoleForm";
import RoleDetails from "../components/roles/RoleDetails";

export default function RolesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [selectedRole, setSelectedRole] = useState(null);
  const [editingRole, setEditingRole] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchCurrentUser = async () => {
      const user = await base44.auth.me();
      setCurrentUser(user);
    };
    fetchCurrentUser();
  }, []);

  const { data: roles = [], isLoading } = useQuery({
    queryKey: ['roles'],
    queryFn: () => base44.entities.Role.list('-created_date'),
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Role.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      setShowForm(false);
      setEditingRole(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Role.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      setShowForm(false);
      setEditingRole(null);
      setSelectedRole(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.Role.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['roles'] });
      setSelectedRole(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingRole) {
      updateMutation.mutate({ id: editingRole.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleDelete = (id) => {
    if (window.confirm('Tem a certeza que deseja eliminar esta função? Usuários com esta função perderão o acesso.')) {
      deleteMutation.mutate(id);
    }
  };

  const filteredRoles = roles.filter(role =>
    role.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    role.description?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getUserCountByRole = (roleId) => {
    return users.filter(u => u.custom_role_id === roleId).length;
  };

  const countPermissions = (permissions) => {
    if (!permissions) return 0;
    let count = 0;
    Object.values(permissions).forEach(module => {
      Object.values(module).forEach(perm => {
        if (perm === true) count++;
      });
    });
    return count;
  };

  if (!currentUser) return null;

  if (currentUser.role !== 'admin') {
    return (
      <div className="p-6 lg:p-8">
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-900">
            Acesso restrito apenas a administradores
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <Shield className="w-8 h-8 text-indigo-600" />
            Gestão de Funções e Permissões
          </h1>
          <p className="text-slate-500 mt-1">Criar e gerir funções personalizadas com permissões específicas</p>
        </div>
        <Button 
          onClick={() => {
            setEditingRole(null);
            setShowForm(true);
          }}
          className="bg-indigo-600 hover:bg-indigo-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Nova Função
        </Button>
      </div>

      {/* Info Alert */}
      <Alert className="border-blue-200 bg-blue-50">
        <Shield className="w-4 h-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>Funções Personalizadas:</strong> Crie funções com permissões específicas para diferentes tipos de usuários. 
          Por exemplo: "Gerente" (acesso total), "Técnico de Campo" (apenas manutenções), "Visualizador" (apenas leitura).
        </AlertDescription>
      </Alert>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none shadow-lg bg-gradient-to-br from-indigo-500 to-indigo-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Total de Funções</CardTitle>
              <Shield className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{roles.length}</div>
            <p className="text-xs opacity-80 mt-1">Funções criadas</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Funções Ativas</CardTitle>
              <CheckCircle2 className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{roles.filter(r => r.is_active).length}</div>
            <p className="text-xs opacity-80 mt-1">Em uso</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Usuários Atribuídos</CardTitle>
              <Users className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {users.filter(u => u.custom_role_id).length}
            </div>
            <p className="text-xs opacity-80 mt-1">Com funções personalizadas</p>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <Input
          placeholder="Pesquisar funções..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Role Form */}
      {showForm && (
        <RoleForm
          role={editingRole}
          onSubmit={handleSubmit}
          onCancel={() => {
            setShowForm(false);
            setEditingRole(null);
          }}
          isLoading={createMutation.isPending || updateMutation.isPending}
        />
      )}

      {/* Role Details */}
      {selectedRole && !showForm && (
        <RoleDetails
          role={selectedRole}
          userCount={getUserCountByRole(selectedRole.id)}
          onClose={() => setSelectedRole(null)}
          onEdit={(role) => {
            setEditingRole(role);
            setShowForm(true);
            setSelectedRole(null);
          }}
          onDelete={handleDelete}
        />
      )}

      {/* Roles List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {isLoading ? (
          Array(6).fill(0).map((_, i) => (
            <Card key={i} className="animate-pulse border-none shadow-md">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                <div className="h-3 bg-slate-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-slate-200 rounded"></div>
                  <div className="h-3 bg-slate-200 rounded w-5/6"></div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : filteredRoles.length > 0 ? (
          filteredRoles.map((role) => {
            const userCount = getUserCountByRole(role.id);
            const permCount = countPermissions(role.permissions);
            
            return (
              <Card 
                key={role.id}
                className="border-none shadow-md hover:shadow-lg transition-all cursor-pointer"
                onClick={() => setSelectedRole(role)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg text-slate-900 flex items-center gap-2">
                        {role.is_system_role && <Lock className="w-4 h-4 text-slate-500" />}
                        {role.name}
                      </CardTitle>
                      {role.description && (
                        <p className="text-sm text-slate-500 mt-1 line-clamp-2">{role.description}</p>
                      )}
                    </div>
                    <Badge className={role.is_active ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
                      {role.is_active ? 'Ativa' : 'Inativa'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Permissões:</span>
                    <span className="font-semibold text-slate-900">{permCount} ativas</span>
                  </div>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-slate-600">Usuários:</span>
                    <Badge variant="outline" className="text-xs">
                      <Users className="w-3 h-3 mr-1" />
                      {userCount}
                    </Badge>
                  </div>
                  {role.is_system_role && (
                    <Badge variant="outline" className="text-xs w-full justify-center">
                      <Lock className="w-3 h-3 mr-1" />
                      Função do Sistema
                    </Badge>
                  )}
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="col-span-full text-center py-12">
            <Shield className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <p className="text-slate-500">Nenhuma função encontrada</p>
            <p className="text-sm text-slate-400 mt-2">
              Crie funções personalizadas para organizar permissões
            </p>
          </div>
        )}
      </div>
    </div>
  );
}