
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { FileText, Plus, Search, Download, CheckCircle2, AlertTriangle, XCircle, Printer, Award } from "lucide-react";
import { format } from "date-fns";
import { pt } from "date-fns/locale";
import ReportForm from "../components/reports/ReportForm";
import ReportPDF from "../components/reports/ReportPDF";
import CertificatePDF from "../components/reports/CertificatePDF";
import PermissionGuard, { usePermissions } from "../components/shared/PermissionGuard";

export default function Reports() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [selectedMaintenance, setSelectedMaintenance] = useState(null);
  const [viewingReport, setViewingReport] = useState(null);
  const [viewMode, setViewMode] = useState('list'); // 'list', 'report-pdf', 'certificate-pdf'
  const queryClient = useQueryClient();

  // Permission check
  const { canView, canCreate, canEdit, canDelete } = usePermissions('reports');

  const { data: reports = [], isLoading } = useQuery({
    queryKey: ['reports'],
    queryFn: () => base44.entities.MaintenanceReport.list('-date'),
  });

  const { data: maintenances = [] } = useQuery({
    queryKey: ['maintenances'],
    queryFn: () => base44.entities.Maintenance.list(),
  });

  const { data: technicians = [] } = useQuery({
    queryKey: ['technicians'],
    queryFn: () => base44.entities.Technician.list(),
  });

  const { data: installations = [] } = useQuery({
    queryKey: ['installations'],
    queryFn: () => base44.entities.Installation.list(),
  });

  const { data: equipment = [] } = useQuery({
    queryKey: ['equipment'],
    queryFn: () => base44.entities.Equipment.list(),
  });

  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.MaintenanceReport.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reports'] });
      setShowForm(false);
      setSelectedMaintenance(null);
    },
  });

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const maintenanceId = urlParams.get('maintenance_id');
    if (maintenanceId) {
      const maintenance = maintenances.find(m => m.id === maintenanceId);
      if (maintenance) {
        setSelectedMaintenance(maintenance);
        setShowForm(true);
      }
    }
  }, [maintenances]);

  const handleSubmit = async (data) => {
    await createMutation.mutateAsync(data);
    
    // Update maintenance status to completed if not already
    if (selectedMaintenance && selectedMaintenance.status !== 'completed') {
      await base44.entities.Maintenance.update(selectedMaintenance.id, {
        ...selectedMaintenance,
        status: 'completed',
        completion_date: data.date
      });
      queryClient.invalidateQueries({ queryKey: ['maintenances'] });
    }
  };

  const filteredReports = reports.filter(report =>
    report.report_number?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const completedMaintenancesWithoutReport = maintenances.filter(m => 
    m.status === 'completed' && !reports.some(r => r.maintenance_id === m.id)
  );

  const getConclusionColor = (conclusion) => {
    switch(conclusion) {
      case 'approved': return 'bg-green-100 text-green-800';
      case 'approved_with_observations': return 'bg-yellow-100 text-yellow-800';
      case 'not_approved': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getConclusionLabel = (conclusion) => {
    const labels = {
      approved: 'Aprovado',
      approved_with_observations: 'Aprovado com Observações',
      not_approved: 'Não Aprovado'
    };
    return labels[conclusion] || conclusion;
  };

  const getConclusionIcon = (conclusion) => {
    switch(conclusion) {
      case 'approved': return <CheckCircle2 className="w-4 h-4" />;
      case 'approved_with_observations': return <AlertTriangle className="w-4 h-4" />;
      case 'not_approved': return <XCircle className="w-4 h-4" />;
      default: return null;
    }
  };

  const handlePrintReport = (report) => {
    setViewingReport(report);
    setViewMode('report-pdf');
    setTimeout(() => {
      window.print();
    }, 500);
  };

  const handlePrintCertificate = (report) => {
    setViewingReport(report);
    setViewMode('certificate-pdf');
    setTimeout(() => {
      window.print();
    }, 500);
  };

  const getMaintenanceEquipment = (maintenanceId) => {
    const maintenance = maintenances.find(m => m.id === maintenanceId);
    if (!maintenance) return [];
    return equipment.filter(eq => eq.installation_id === maintenance.installation_id);
  };

  if (viewMode === 'report-pdf' && viewingReport) {
    const maintenance = maintenances.find(m => m.id === viewingReport.maintenance_id);
    const installation = installations.find(i => i.id === maintenance?.installation_id);
    const client = clients.find(c => c.id === installation?.client_id);
    const technician = technicians.find(t => t.id === viewingReport.technician_id);
    const reportEquipment = getMaintenanceEquipment(viewingReport.maintenance_id);

    return (
      <>
        <style>{`
          @media print {
            body * { visibility: hidden; }
            #report-pdf, #report-pdf * { visibility: visible; }
            #report-pdf { position: absolute; left: 0; top: 0; width: 100%; }
          }
        `}</style>
        <div className="print:hidden p-4 bg-slate-100">
          <Button onClick={() => setViewMode('list')} variant="outline">
            ← Voltar à Lista
          </Button>
        </div>
        <ReportPDF
          report={viewingReport}
          maintenance={maintenance}
          installation={installation}
          client={client}
          technician={technician}
          equipment={reportEquipment}
        />
      </>
    );
  }

  if (viewMode === 'certificate-pdf' && viewingReport) {
    const maintenance = maintenances.find(m => m.id === viewingReport.maintenance_id);
    const installation = installations.find(i => i.id === maintenance?.installation_id);
    const client = clients.find(c => c.id === installation?.client_id);
    const technician = technicians.find(t => t.id === viewingReport.technician_id);

    return (
      <>
        <style>{`
          @media print {
            body * { visibility: hidden; }
            #certificate-pdf, #certificate-pdf * { visibility: visible; }
            #certificate-pdf { position: absolute; left: 0; top: 0; width: 100%; }
          }
        `}</style>
        <div className="print:hidden p-4 bg-slate-100">
          <Button onClick={() => setViewMode('list')} variant="outline">
            ← Voltar à Lista
          </Button>
        </div>
        <CertificatePDF
          report={viewingReport}
          maintenance={maintenance}
          installation={installation}
          client={client}
          technician={technician}
        />
      </>
    );
  }

  return (
    <PermissionGuard module="reports" action="view">
      <div className="p-6 lg:p-8 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <FileText className="w-8 h-8 text-emerald-600" />
              Relatórios de Manutenção
            </h1>
            <p className="text-slate-500 mt-1">Relatórios com checklist EN54</p>
          </div>
          {canCreate && completedMaintenancesWithoutReport.length > 0 && !showForm && (
            <div className="flex gap-2">
              <Button 
                onClick={() => {
                  setSelectedMaintenance(null);
                  setShowForm(true);
                }}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Novo Relatório
              </Button>
            </div>
          )}
        </div>

        {completedMaintenancesWithoutReport.length > 0 && !showForm && (
          <Card className="border-orange-200 bg-orange-50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-orange-600 mt-0.5" />
                <div className="flex-1">
                  <p className="font-semibold text-orange-900">
                    {completedMaintenancesWithoutReport.length} manutenções concluídas sem relatório
                  </p>
                  <p className="text-sm text-orange-700 mt-1">
                    Crie relatórios de inspeção para documentar as manutenções concluídas
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {!showForm && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Pesquisar relatórios..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        {showForm && canCreate && (
          <ReportForm
            maintenance={selectedMaintenance}
            technicians={technicians}
            equipment={selectedMaintenance ? getMaintenanceEquipment(selectedMaintenance.id) : equipment}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setSelectedMaintenance(null);
              window.history.replaceState({}, '', '/Reports');
            }}
            isLoading={createMutation.isPending}
          />
        )}

        {!showForm && (
          <div className="space-y-4">
            {isLoading ? (
              Array(5).fill(0).map((_, i) => (
                <Card key={i} className="animate-pulse border-none shadow-md">
                  <CardContent className="p-6">
                    <div className="space-y-3">
                      <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                      <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : filteredReports.length > 0 ? (
              filteredReports.map((report) => {
                const maintenance = maintenances.find(m => m.id === report.maintenance_id);
                const technician = technicians.find(t => t.id === report.technician_id);
                const installation = installations.find(i => i.id === maintenance?.installation_id);
                
                return (
                  <Card 
                    key={report.id}
                    className="border-none shadow-md hover:shadow-lg transition-all"
                  >
                    <CardHeader>
                      <div className="flex flex-col md:flex-row justify-between gap-4">
                        <div className="flex-1">
                          <CardTitle className="text-lg text-slate-900 flex items-center gap-2">
                            <FileText className="w-5 h-5 text-emerald-600" />
                            Relatório {report.report_number}
                          </CardTitle>
                          <p className="text-sm text-slate-500 mt-1">
                            {format(new Date(report.date), "dd 'de' MMMM, yyyy", { locale: pt })}
                          </p>
                          {installation && (
                            <p className="text-sm text-slate-600 mt-1">📍 {installation.name}</p>
                          )}
                        </div>
                        <div className="flex flex-col items-start md:items-end gap-2">
                          <div className="flex gap-2">
                            <Badge className={getConclusionColor(report.conclusion)}>
                              {getConclusionIcon(report.conclusion)}
                              <span className="ml-1">{getConclusionLabel(report.conclusion)}</span>
                            </Badge>
                            {report.certificate_issued && (
                              <Badge className="bg-blue-100 text-blue-800">
                                <CheckCircle2 className="w-3 h-3 mr-1" />
                                Certificado
                              </Badge>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handlePrintReport(report)}
                              className="text-emerald-600 hover:text-emerald-700"
                            >
                              <Printer className="w-4 h-4 mr-2" />
                              Exportar Relatório
                            </Button>
                            {report.certificate_issued && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handlePrintCertificate(report)}
                                className="text-blue-600 hover:text-blue-700"
                              >
                                <Award className="w-4 h-4 mr-2" />
                                Certificado EN54
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {technician && (
                        <p className="text-sm text-slate-600">👷 Técnico: {technician.name}</p>
                      )}

                      {report.en54_checklist && (
                        <div className="bg-slate-50 rounded-lg p-4">
                          <h4 className="font-semibold text-sm text-slate-900 mb-3">Checklist EN54</h4>
                          <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                            {Object.entries(report.en54_checklist).map(([key, value]) => (
                              <div key={key} className="flex items-center gap-2">
                                {value ? (
                                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                                ) : (
                                  <XCircle className="w-4 h-4 text-red-600" />
                                )}
                                <span className="text-slate-600">
                                  {key.replace(/_/g, ' ')}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {report.defects_found && report.defects_found.length > 0 && (
                        <div className="bg-orange-50 rounded-lg p-4">
                          <h4 className="font-semibold text-sm text-orange-900 mb-2">
                            Defeitos Encontrados ({report.defects_found.length})
                          </h4>
                          <div className="space-y-2">
                            {report.defects_found.slice(0, 3).map((defect, i) => (
                              <div key={i} className="text-sm">
                                <Badge variant="outline" className="mr-2">
                                  {defect.severity}
                                </Badge>
                                <span className="text-slate-700">{defect.description}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {report.recommendations && (
                        <div className="border-l-4 border-blue-500 pl-4 py-2">
                          <p className="text-sm text-slate-600">{report.recommendations}</p>
                        </div>
                      )}

                      {report.next_inspection_date && (
                        <div className="flex items-center gap-2 text-sm text-slate-600">
                          <span>Próxima inspeção:</span>
                          <span className="font-medium">
                            {format(new Date(report.next_inspection_date), "dd/MM/yyyy")}
                          </span>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })
            ) : (
              <div className="text-center py-12">
                <FileText className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Nenhum relatório encontrado</p>
                <p className="text-sm text-slate-400 mt-2">
                  Crie relatórios após a conclusão das manutenções
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </PermissionGuard>
  );
}
