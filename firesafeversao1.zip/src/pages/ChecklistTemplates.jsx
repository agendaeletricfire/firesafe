
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Settings, Plus, Search, Edit, Trash2, Copy, CheckCircle2 } from "lucide-react";
import TemplateForm from "../components/checklist/TemplateForm";
import PermissionGuard, { usePermissions } from "../components/shared/PermissionGuard";

export default function ChecklistTemplates() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const queryClient = useQueryClient();

  // Permission check
  const { canView, canCreate, canEdit, canDelete } = usePermissions('checklists');

  const { data: templates = [], isLoading } = useQuery({
    queryKey: ['checklist-templates'],
    queryFn: () => base44.entities.ChecklistTemplate.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.ChecklistTemplate.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['checklist-templates'] });
      setShowForm(false);
      setEditingTemplate(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.ChecklistTemplate.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['checklist-templates'] });
      setShowForm(false);
      setEditingTemplate(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => base44.entities.ChecklistTemplate.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['checklist-templates'] });
    },
  });

  const handleSubmit = (data) => {
    if (editingTemplate) {
      updateMutation.mutate({ id: editingTemplate.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const handleDuplicate = (template) => {
    const newTemplate = {
      ...template,
      name: `${template.name} (Cópia)`,
      is_default: false
    };
    delete newTemplate.id;
    delete newTemplate.created_date;
    delete newTemplate.updated_date;
    createMutation.mutate(newTemplate);
  };

  const handleDelete = (id) => {
    if (confirm('Tem certeza que deseja eliminar este template?')) {
      deleteMutation.mutate(id);
    }
  };

  const filteredTemplates = templates.filter(t =>
    t.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    t.standard?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStandardColor = (standard) => {
    switch(standard) {
      case 'EN54': return 'bg-blue-100 text-blue-800';
      case 'LPCB': return 'bg-green-100 text-green-800';
      case 'NFPA': return 'bg-orange-100 text-orange-800';
      case 'Custom': return 'bg-purple-100 text-purple-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  return (
    <PermissionGuard module="checklists" action="view">
      <div className="p-6 lg:p-8 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Settings className="w-8 h-8 text-indigo-600" />
              Templates de Checklist
            </h1>
            <p className="text-slate-500 mt-1">Gerir templates de inspeção e conformidade</p>
          </div>
          {canCreate && (
            <Button 
              onClick={() => {
                setEditingTemplate(null);
                setShowForm(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Template
            </Button>
          )}
        </div>

        {!showForm && (
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
            <Input
              placeholder="Pesquisar templates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
        )}

        {showForm && canCreate && (
          <TemplateForm
            template={editingTemplate}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingTemplate(null);
            }}
            isLoading={createMutation.isPending || updateMutation.isPending}
          />
        )}

        {!showForm && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="animate-pulse border-none shadow-md">
                  <CardHeader className="space-y-2">
                    <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                    <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <div className="h-3 bg-slate-200 rounded"></div>
                      <div className="h-3 bg-slate-200 rounded w-5/6"></div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : filteredTemplates.length > 0 ? (
              filteredTemplates.map((template) => (
                <Card 
                  key={template.id}
                  className="border-none shadow-md hover:shadow-lg transition-all"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-lg text-slate-900 flex items-center gap-2">
                          {template.name}
                          {template.is_default && (
                            <CheckCircle2 className="w-4 h-4 text-green-600" />
                          )}
                        </CardTitle>
                        {template.description && (
                          <p className="text-sm text-slate-500 mt-1">{template.description}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Badge className={getStandardColor(template.standard)}>
                        {template.standard}
                      </Badge>
                      <Badge variant="outline">
                        {template.items?.length || 0} itens
                      </Badge>
                      {template.status === 'active' ? (
                        <Badge className="bg-green-100 text-green-800">Ativo</Badge>
                      ) : (
                        <Badge className="bg-slate-100 text-slate-800">Inativo</Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      <p className="text-sm text-slate-600 font-medium">Categorias:</p>
                      <div className="flex flex-wrap gap-1">
                        {[...new Set(template.items?.map(i => i.category) || [])].map((cat, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {cat}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 mt-4">
                      {canEdit && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setEditingTemplate(template);
                            setShowForm(true);
                          }}
                          className="flex-1"
                        >
                          <Edit className="w-3 h-3 mr-2" />
                          Editar
                        </Button>
                      )}
                      {canCreate && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDuplicate(template)}
                          className="flex-1"
                        >
                          <Copy className="w-3 h-3 mr-2" />
                          Duplicar
                        </Button>
                      )}
                      {canDelete && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(template.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-12">
                <Settings className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                <p className="text-slate-500">Nenhum template encontrado</p>
                <p className="text-sm text-slate-400 mt-2">
                  Crie um template para começar
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </PermissionGuard>
  );
}
