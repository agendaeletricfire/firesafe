
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Building2, Plus, Search, MapPin, Layers, AlertCircle } from "lucide-react";
import InstallationForm from "../components/installations/InstallationForm";
import InstallationDetails from "../components/installations/InstallationDetails";
import PermissionGuard, { usePermissions } from "../components/shared/PermissionGuard";

export default function Installations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [selectedInstallation, setSelectedInstallation] = useState(null);
  const [editingInstallation, setEditingInstallation] = useState(null);
  const queryClient = useQueryClient();

  // Permission check
  const { canView, canCreate, canEdit, canDelete } = usePermissions('installations');

  const { data: installations = [], isLoading } = useQuery({
    queryKey: ['installations'],
    queryFn: () => base44.entities.Installation.list('-created_date'),
  });

  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Installation.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['installations'] });
      setShowForm(false);
      setEditingInstallation(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Installation.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['installations'] });
      setShowForm(false);
      setEditingInstallation(null);
      setSelectedInstallation(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingInstallation) {
      updateMutation.mutate({ id: editingInstallation.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredInstallations = installations.filter(inst =>
    inst.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inst.city?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    inst.type?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getClientName = (clientId) => {
    const client = clients.find(c => c.id === clientId);
    return client?.name || 'Cliente não encontrado';
  };

  const getRiskColor = (risk) => {
    switch(risk) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-orange-100 text-orange-800';
      case 'very_high': return 'bg-red-100 text-red-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getRiskLabel = (risk) => {
    switch(risk) {
      case 'low': return 'Baixo';
      case 'medium': return 'Médio';
      case 'high': return 'Alto';
      case 'very_high': return 'Muito Alto';
      default: return risk;
    }
  };

  const getTypeLabel = (type) => {
    const types = {
      residential: 'Residencial',
      commercial: 'Comercial',
      industrial: 'Industrial',
      public: 'Público',
      warehouse: 'Armazém',
      office: 'Escritório'
    };
    return types[type] || type;
  };

  return (
    <PermissionGuard module="installations" action="view">
      <div className="p-6 lg:p-8 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <Building2 className="w-8 h-8 text-purple-600" />
              Instalações
            </h1>
            <p className="text-slate-500 mt-1">Gerir edifícios e localizações</p>
          </div>
          {canCreate && (
            <Button 
              onClick={() => {
                setEditingInstallation(null);
                setShowForm(true);
              }}
              className="bg-purple-600 hover:bg-purple-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Instalação
            </Button>
          )}
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Pesquisar instalações..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {showForm && canCreate && (
          <InstallationForm
            installation={editingInstallation}
            clients={clients}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingInstallation(null);
            }}
            isLoading={createMutation.isPending || updateMutation.isPending}
          />
        )}

        {selectedInstallation && !showForm && (
          <InstallationDetails
            installation={selectedInstallation}
            clientName={getClientName(selectedInstallation.client_id)}
            onClose={() => setSelectedInstallation(null)}
            onEdit={canEdit ? (inst) => {
              setEditingInstallation(inst);
              setShowForm(true);
              setSelectedInstallation(null);
            } : null}
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse">
                <CardHeader className="space-y-2">
                  <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-slate-200 rounded"></div>
                    <div className="h-3 bg-slate-200 rounded w-5/6"></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredInstallations.length > 0 ? (
            filteredInstallations.map((installation) => (
              <Card 
                key={installation.id}
                className="hover:shadow-lg transition-all cursor-pointer border-none shadow-md"
                onClick={() => setSelectedInstallation(installation)}
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg text-slate-900">{installation.name}</CardTitle>
                      <p className="text-sm text-slate-500 mt-1">
                        {getClientName(installation.client_id)}
                      </p>
                    </div>
                    <Badge className={installation.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-800'}>
                      {installation.status === 'active' ? 'Ativa' : 'Inativa'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline" className="text-xs">
                      {getTypeLabel(installation.type)}
                    </Badge>
                    <Badge className={getRiskColor(installation.risk_level)}>
                      <AlertCircle className="w-3 h-3 mr-1" />
                      {getRiskLabel(installation.risk_level)}
                    </Badge>
                  </div>
                  {installation.city && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <MapPin className="w-4 h-4" />
                      <span>{installation.city}</span>
                    </div>
                  )}
                  {installation.area_m2 && (
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Layers className="w-4 h-4" />
                      <span>{installation.area_m2} m²</span>
                      {installation.floors && <span>• {installation.floors} pisos</span>}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <Building2 className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">Nenhuma instalação encontrada</p>
            </div>
          )}
        </div>
      </div>
    </PermissionGuard>
  );
}
