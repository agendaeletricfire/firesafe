import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Mail, 
  Save, 
  Send, 
  CheckCircle2, 
  XCircle, 
  AlertTriangle,
  Info,
  Eye,
  EyeOff
} from "lucide-react";

export default function EmailSettings() {
  const [user, setUser] = useState(null);
  const [showPassword, setShowPassword] = useState(false);
  const [testEmail, setTestEmail] = useState("");
  const [testResult, setTestResult] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await base44.auth.me();
      setUser(currentUser);
      setTestEmail(currentUser.email);
    };
    fetchUser();
  }, []);

  const { data: configs = [], isLoading } = useQuery({
    queryKey: ['email-configs'],
    queryFn: () => base44.entities.EmailConfig.list(),
  });

  const activeConfig = configs.find(c => c.is_active) || {};

  const [formData, setFormData] = useState({
    provider: "custom",
    smtp_host: "",
    smtp_port: 587,
    smtp_user: "",
    smtp_password: "",
    from_email: "",
    from_name: "FireSafe Pro",
    use_ssl: true,
    is_active: true,
    test_status: "not_tested",
    ...activeConfig
  });

  useEffect(() => {
    if (activeConfig.id) {
      setFormData(activeConfig);
    }
  }, [activeConfig.id]);

  const saveMutation = useMutation({
    mutationFn: async (data) => {
      if (activeConfig.id) {
        return await base44.entities.EmailConfig.update(activeConfig.id, data);
      } else {
        return await base44.entities.EmailConfig.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['email-configs'] });
    },
  });

  const testMutation = useMutation({
    mutationFn: async () => {
      // Test email sending
      return await base44.integrations.Core.SendEmail({
        to: testEmail,
        subject: "🔥 Teste de Email - FireSafe Pro",
        body: `
Olá!

Este é um email de teste do sistema FireSafe Pro.

Se recebeu este email, a configuração está correta! ✅

---
FireSafe Pro
Sistema de Gestão de Segurança contra Incêndios
        `
      });
    },
    onSuccess: () => {
      setTestResult({
        status: "success",
        message: "Email de teste enviado com sucesso! Verifique a caixa de entrada."
      });
      
      // Update config with test status
      const updatedData = {
        ...formData,
        last_test_date: new Date().toISOString(),
        test_status: "success"
      };
      saveMutation.mutate(updatedData);
    },
    onError: (error) => {
      setTestResult({
        status: "error",
        message: `Erro ao enviar email: ${error.message}`
      });
    }
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleProviderChange = (provider) => {
    const presets = {
      gmail: {
        smtp_host: "smtp.gmail.com",
        smtp_port: 587,
        use_ssl: true
      },
      outlook: {
        smtp_host: "smtp-mail.outlook.com",
        smtp_port: 587,
        use_ssl: true
      },
      sendgrid: {
        smtp_host: "smtp.sendgrid.net",
        smtp_port: 587,
        use_ssl: true
      },
      custom: {
        smtp_host: "",
        smtp_port: 587,
        use_ssl: true
      }
    };

    setFormData(prev => ({
      ...prev,
      provider,
      ...presets[provider]
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    saveMutation.mutate(formData);
  };

  const handleTest = () => {
    setTestResult(null);
    testMutation.mutate();
  };

  if (!user) return null;

  if (user.role !== 'admin') {
    return (
      <div className="p-6 lg:p-8">
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="w-4 h-4 text-red-600" />
          <AlertDescription className="text-red-900">
            Acesso restrito apenas a administradores
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
          <Mail className="w-8 h-8 text-blue-600" />
          Configurações de Email
        </h1>
        <p className="text-slate-500 mt-1">Configure o servidor SMTP para envio de emails</p>
      </div>

      {/* Info Alert */}
      <Alert className="border-blue-200 bg-blue-50">
        <Info className="w-4 h-4 text-blue-600" />
        <AlertDescription className="text-blue-900">
          <strong>Emails são enviados para:</strong>
          <ul className="list-disc list-inside mt-2 text-sm">
            <li>Notificações de manutenção agendada aos clientes</li>
            <li>Alertas de licença (futuro)</li>
            <li>Relatórios automáticos (futuro)</li>
          </ul>
        </AlertDescription>
      </Alert>

      {/* Main Form */}
      <form onSubmit={handleSubmit}>
        <Card className="border-none shadow-lg">
          <CardHeader className="border-b border-slate-100">
            <CardTitle>Configuração SMTP</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-6">
            {/* Provider Selection */}
            <div className="space-y-2">
              <Label htmlFor="provider">Provedor de Email</Label>
              <Select value={formData.provider} onValueChange={handleProviderChange}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="gmail">
                    <div className="flex items-center gap-2">
                      <span>Gmail</span>
                      <Badge variant="outline" className="text-xs">smtp.gmail.com</Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="outlook">
                    <div className="flex items-center gap-2">
                      <span>Outlook/Hotmail</span>
                      <Badge variant="outline" className="text-xs">smtp-mail.outlook.com</Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="sendgrid">
                    <div className="flex items-center gap-2">
                      <span>SendGrid</span>
                      <Badge variant="outline" className="text-xs">smtp.sendgrid.net</Badge>
                    </div>
                  </SelectItem>
                  <SelectItem value="custom">Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* SMTP Settings */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="smtp_host">Servidor SMTP *</Label>
                <Input
                  id="smtp_host"
                  value={formData.smtp_host}
                  onChange={(e) => handleChange('smtp_host', e.target.value)}
                  placeholder="smtp.gmail.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp_port">Porta SMTP *</Label>
                <Input
                  id="smtp_port"
                  type="number"
                  value={formData.smtp_port}
                  onChange={(e) => handleChange('smtp_port', parseInt(e.target.value))}
                  placeholder="587"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp_user">Usuário SMTP *</Label>
                <Input
                  id="smtp_user"
                  type="email"
                  value={formData.smtp_user}
                  onChange={(e) => handleChange('smtp_user', e.target.value)}
                  placeholder="seu-email@gmail.com"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="smtp_password">Password SMTP *</Label>
                <div className="relative">
                  <Input
                    id="smtp_password"
                    type={showPassword ? "text" : "password"}
                    value={formData.smtp_password}
                    onChange={(e) => handleChange('smtp_password', e.target.value)}
                    placeholder="••••••••"
                    required
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-0 top-0"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </Button>
                </div>
              </div>
            </div>

            {/* From Settings */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="from_email">Email do Remetente *</Label>
                <Input
                  id="from_email"
                  type="email"
                  value={formData.from_email}
                  onChange={(e) => handleChange('from_email', e.target.value)}
                  placeholder="noreply@ieet.pt"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="from_name">Nome do Remetente *</Label>
                <Input
                  id="from_name"
                  value={formData.from_name}
                  onChange={(e) => handleChange('from_name', e.target.value)}
                  placeholder="FireSafe Pro"
                  required
                />
              </div>
            </div>

            {/* SSL Option */}
            <div className="flex items-center gap-2">
              <Checkbox
                id="use_ssl"
                checked={formData.use_ssl}
                onCheckedChange={(checked) => handleChange('use_ssl', checked)}
              />
              <Label htmlFor="use_ssl" className="cursor-pointer">
                Usar SSL/TLS (Recomendado)
              </Label>
            </div>

            {/* Active Status */}
            <div className="flex items-center gap-2">
              <Checkbox
                id="is_active"
                checked={formData.is_active}
                onCheckedChange={(checked) => handleChange('is_active', checked)}
              />
              <Label htmlFor="is_active" className="cursor-pointer">
                Ativar esta configuração
              </Label>
            </div>

            {/* Save Button */}
            <div className="flex justify-end pt-4 border-t border-slate-200">
              <Button 
                type="submit" 
                disabled={saveMutation.isPending}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Save className="w-4 h-4 mr-2" />
                {saveMutation.isPending ? 'A guardar...' : 'Guardar Configuração'}
              </Button>
            </div>

            {saveMutation.isSuccess && (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle2 className="w-4 h-4 text-green-600" />
                <AlertDescription className="text-green-900">
                  Configuração guardada com sucesso!
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </form>

      {/* Test Email */}
      {activeConfig.id && (
        <Card className="border-none shadow-lg">
          <CardHeader className="border-b border-slate-100">
            <CardTitle>Testar Envio de Email</CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="space-y-2">
              <Label htmlFor="test_email">Enviar email de teste para:</Label>
              <div className="flex gap-2">
                <Input
                  id="test_email"
                  type="email"
                  value={testEmail}
                  onChange={(e) => setTestEmail(e.target.value)}
                  placeholder="seu-email@exemplo.com"
                  className="flex-1"
                />
                <Button 
                  onClick={handleTest}
                  disabled={testMutation.isPending || !testEmail}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  <Send className="w-4 h-4 mr-2" />
                  {testMutation.isPending ? 'A enviar...' : 'Enviar Teste'}
                </Button>
              </div>
            </div>

            {testResult && (
              <Alert className={
                testResult.status === 'success' 
                  ? 'border-green-200 bg-green-50' 
                  : 'border-red-200 bg-red-50'
              }>
                {testResult.status === 'success' ? (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                ) : (
                  <XCircle className="w-4 h-4 text-red-600" />
                )}
                <AlertDescription className={
                  testResult.status === 'success' ? 'text-green-900' : 'text-red-900'
                }>
                  {testResult.message}
                </AlertDescription>
              </Alert>
            )}

            {activeConfig.last_test_date && (
              <div className="text-sm text-slate-600">
                Último teste: {new Date(activeConfig.last_test_date).toLocaleString('pt-PT')}
                {activeConfig.test_status === 'success' && (
                  <Badge className="ml-2 bg-green-100 text-green-800">
                    <CheckCircle2 className="w-3 h-3 mr-1" />
                    Sucesso
                  </Badge>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Help Section */}
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="text-lg">Como Configurar</CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4 text-sm">
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">📧 Gmail:</h4>
              <ul className="list-disc list-inside text-slate-600 space-y-1">
                <li>Ativar "Verificação em 2 passos" na conta Google</li>
                <li>Criar "Password de aplicação" em: myaccount.google.com/apppasswords</li>
                <li>Usar a password de aplicação (16 caracteres)</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">📧 Outlook:</h4>
              <ul className="list-disc list-inside text-slate-600 space-y-1">
                <li>Pode usar a password normal da conta</li>
                <li>Ou criar password de aplicação em: account.live.com/proofs/AppPassword</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-slate-900 mb-2">⚙️ Outro SMTP:</h4>
              <ul className="list-disc list-inside text-slate-600 space-y-1">
                <li>Consultar documentação do provedor</li>
                <li>Verificar servidor, porta e credenciais</li>
                <li>Normalmente usa porta 587 (TLS) ou 465 (SSL)</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}