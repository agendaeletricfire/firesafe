
import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { UserCog, Plus, Search, Mail, Phone, MapPin, Save, X, Edit } from "lucide-react";
import PermissionGuard, { usePermissions } from "../components/shared/PermissionGuard";

export default function Technicians() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingTechnician, setEditingTechnician] = useState(null);
  const queryClient = useQueryClient();

  // Permission check
  const { canView, canCreate, canEdit, canDelete } = usePermissions('technicians');

  const { data: technicians = [], isLoading } = useQuery({
    queryKey: ['technicians'],
    queryFn: () => base44.entities.Technician.list('-created_date'),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Technician.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['technicians'] });
      setShowForm(false);
      setEditingTechnician(null);
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Technician.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['technicians'] });
      setShowForm(false);
      setEditingTechnician(null);
    },
  });

  const handleSubmit = (data) => {
    if (editingTechnician) {
      updateMutation.mutate({ id: editingTechnician.id, data });
    } else {
      createMutation.mutate(data);
    }
  };

  const filteredTechnicians = technicians.filter(tech =>
    tech.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tech.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    tech.location?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusColor = (status) => {
    switch(status) {
      case 'available': return 'bg-green-100 text-green-800';
      case 'busy': return 'bg-orange-100 text-orange-800';
      case 'on_leave': return 'bg-blue-100 text-blue-800';
      case 'inactive': return 'bg-slate-100 text-slate-800';
      default: return 'bg-slate-100 text-slate-800';
    }
  };

  const getStatusLabel = (status) => {
    const labels = {
      available: 'Disponível',
      busy: 'Ocupado',
      on_leave: 'De Férias',
      inactive: 'Inativo'
    };
    return labels[status] || status;
  };

  return (
    <PermissionGuard module="technicians" action="view">
      <div className="p-6 lg:p-8 space-y-6">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
              <UserCog className="w-8 h-8 text-indigo-600" />
              Técnicos
            </h1>
            <p className="text-slate-500 mt-1">Gerir equipa de técnicos</p>
          </div>
          {canCreate && (
            <Button 
              onClick={() => {
                setEditingTechnician(null);
                setShowForm(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Novo Técnico
            </Button>
          )}
        </div>

        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
          <Input
            placeholder="Pesquisar técnicos..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>

        {showForm && canCreate && (
          <TechnicianForm
            technician={editingTechnician}
            onSubmit={handleSubmit}
            onCancel={() => {
              setShowForm(false);
              setEditingTechnician(null);
            }}
            isLoading={createMutation.isPending || updateMutation.isPending}
          />
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(6).fill(0).map((_, i) => (
              <Card key={i} className="animate-pulse border-none shadow-md">
                <CardHeader className="space-y-2">
                  <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                  <div className="h-3 bg-slate-200 rounded w-1/2"></div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="h-3 bg-slate-200 rounded"></div>
                    <div className="h-3 bg-slate-200 rounded w-5/6"></div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : filteredTechnicians.length > 0 ? (
            filteredTechnicians.map((technician) => (
              <Card 
                key={technician.id}
                className="border-none shadow-md hover:shadow-lg transition-all"
              >
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-lg text-slate-900">{technician.name}</CardTitle>
                      {technician.certification_number && (
                        <p className="text-sm text-slate-500 mt-1">Cert: {technician.certification_number}</p>
                      )}
                    </div>
                    <Badge className={getStatusColor(technician.status)}>
                      {getStatusLabel(technician.status)}
                    </Badge>
                  </div>
                </CardHeader>
                {canEdit && (
                  <CardContent className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-slate-600">
                      <Mail className="w-4 h-4" />
                      <span className="truncate">{technician.email}</span>
                    </div>
                    {technician.phone && (
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <Phone className="w-4 h-4" />
                        <span>{technician.phone}</span>
                      </div>
                    )}
                    {technician.location && (
                      <div className="flex items-center gap-2 text-sm text-slate-600">
                        <MapPin className="w-4 h-4" />
                        <span>{technician.location}</span>
                      </div>
                    )}
                    {technician.specialization && technician.specialization.length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {technician.specialization.map((spec, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {spec}
                          </Badge>
                        ))}
                      </div>
                    )}
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="w-full mt-2"
                      onClick={() => {
                        setEditingTechnician(technician);
                        setShowForm(true);
                      }}
                    >
                      <Edit className="w-3 h-3 mr-2" />
                      Editar
                    </Button>
                  </CardContent>
                )}
              </Card>
            ))
          ) : (
            <div className="col-span-full text-center py-12">
              <UserCog className="w-12 h-12 text-slate-300 mx-auto mb-4" />
              <p className="text-slate-500">Nenhum técnico encontrado</p>
            </div>
          )}
        </div>
      </div>
    </PermissionGuard>
  );
}

function TechnicianForm({ technician, onSubmit, onCancel, isLoading }) {
  const [formData, setFormData] = useState(technician || {
    name: "",
    email: "",
    phone: "",
    specialization: [],
    certification_number: "",
    certification_expiry: "",
    location: "",
    status: "available",
    notes: ""
  });

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const specializationOptions = ['extinguishers', 'fire_alarms', 'sprinklers', 'emergency_lighting', 'fire_doors', 'general'];

  return (
    <Card className="border-none shadow-lg">
      <CardHeader className="border-b border-slate-100">
        <CardTitle>{technician ? 'Editar Técnico' : 'Novo Técnico'}</CardTitle>
      </CardHeader>
      <form onSubmit={handleSubmit}>
        <CardContent className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleChange('name', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleChange('email', e.target.value)}
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Localização</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleChange('location', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="certification_number">Nº Certificação</Label>
              <Input
                id="certification_number"
                value={formData.certification_number}
                onChange={(e) => handleChange('certification_number', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="certification_expiry">Validade Certificação</Label>
              <Input
                id="certification_expiry"
                type="date"
                value={formData.certification_expiry}
                onChange={(e) => handleChange('certification_expiry', e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="available">Disponível</SelectItem>
                  <SelectItem value="busy">Ocupado</SelectItem>
                  <SelectItem value="on_leave">De Férias</SelectItem>
                  <SelectItem value="inactive">Inativo</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="notes">Observações</Label>
              <Textarea
                id="notes"
                value={formData.notes}
                onChange={(e) => handleChange('notes', e.target.value)}
                rows={3}
              />
            </div>
          </div>
        </CardContent>
        <CardFooter className="border-t border-slate-100 flex justify-end gap-3">
          <Button type="button" variant="outline" onClick={onCancel}>
            <X className="w-4 h-4 mr-2" />
            Cancelar
          </Button>
          <Button type="submit" disabled={isLoading} className="bg-indigo-600 hover:bg-indigo-700">
            <Save className="w-4 h-4 mr-2" />
            {isLoading ? 'A guardar...' : 'Guardar'}
          </Button>
        </CardFooter>
      </form>
    </Card>
  );
}
