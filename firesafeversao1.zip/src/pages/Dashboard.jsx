import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  Users,
  Building2,
  Wrench,
  Calendar,
  AlertTriangle,
  TrendingUp,
  CheckCircle2,
  Clock,
  Flame
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { format, isAfter, isBefore, addDays } from "date-fns";
import { pt } from "date-fns/locale";

export default function Dashboard() {
  const { data: clients = [] } = useQuery({
    queryKey: ['clients'],
    queryFn: () => base44.entities.Client.list(),
  });

  const { data: installations = [] } = useQuery({
    queryKey: ['installations'],
    queryFn: () => base44.entities.Installation.list(),
  });

  const { data: equipment = [] } = useQuery({
    queryKey: ['equipment'],
    queryFn: () => base44.entities.Equipment.list(),
  });

  const { data: maintenances = [] } = useQuery({
    queryKey: ['maintenances'],
    queryFn: () => base44.entities.Maintenance.list('-scheduled_date'),
  });

  const activeClients = clients.filter(c => c.status === 'active').length;
  const activeInstallations = installations.filter(i => i.status === 'active').length;
  const totalEquipment = equipment.length;
  
  const needsMaintenance = equipment.filter(e => 
    e.status === 'needs_maintenance' || e.status === 'needs_replacement'
  ).length;

  const upcomingMaintenances = maintenances.filter(m => 
    m.status === 'scheduled' && isBefore(new Date(m.scheduled_date), addDays(new Date(), 7))
  ).length;

  const completedThisMonth = maintenances.filter(m => 
    m.status === 'completed' && 
    new Date(m.completion_date).getMonth() === new Date().getMonth()
  ).length;

  const equipmentExpiringSoon = equipment.filter(e => 
    e.expiry_date && isBefore(new Date(e.expiry_date), addDays(new Date(), 30))
  );

  const recentMaintenances = maintenances.slice(0, 5);

  return (
    <div className="p-6 lg:p-8 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-slate-900 flex items-center gap-3">
            <div className="w-12 h-12 bg-gradient-to-br from-red-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
              <Flame className="w-7 h-7 text-white" />
            </div>
            Dashboard
          </h1>
          <p className="text-slate-500 mt-2">Visão geral do sistema de manutenção</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="border-none shadow-lg bg-gradient-to-br from-blue-500 to-blue-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Clientes Ativos</CardTitle>
              <Users className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{activeClients}</div>
            <p className="text-xs opacity-80 mt-1">Total: {clients.length}</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-purple-500 to-purple-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Instalações</CardTitle>
              <Building2 className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{activeInstallations}</div>
            <p className="text-xs opacity-80 mt-1">Ativas e monitorizadas</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-green-500 to-green-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Equipamentos</CardTitle>
              <Wrench className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalEquipment}</div>
            <p className="text-xs opacity-80 mt-1">{needsMaintenance} necessitam atenção</p>
          </CardContent>
        </Card>

        <Card className="border-none shadow-lg bg-gradient-to-br from-orange-500 to-orange-600 text-white">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium opacity-90">Manutenções</CardTitle>
              <Calendar className="w-5 h-5 opacity-80" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{upcomingMaintenances}</div>
            <p className="text-xs opacity-80 mt-1">Próximos 7 dias</p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* Alerts */}
        <Card className="lg:col-span-2 border-none shadow-lg">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="flex items-center gap-2 text-slate-900">
              <AlertTriangle className="w-5 h-5 text-orange-500" />
              Alertas e Atenções
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="space-y-4">
              {needsMaintenance > 0 && (
                <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-red-900">
                      {needsMaintenance} equipamentos necessitam manutenção
                    </p>
                    <p className="text-sm text-red-700 mt-1">
                      Verifique os equipamentos que precisam de atenção urgente
                    </p>
                  </div>
                </div>
              )}

              {equipmentExpiringSoon.length > 0 && (
                <div className="flex items-start gap-3 p-4 bg-orange-50 border border-orange-200 rounded-lg">
                  <Clock className="w-5 h-5 text-orange-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-orange-900">
                      {equipmentExpiringSoon.length} equipamentos com validade próxima
                    </p>
                    <p className="text-sm text-orange-700 mt-1">
                      Expiram nos próximos 30 dias
                    </p>
                  </div>
                </div>
              )}

              {upcomingMaintenances > 0 && (
                <div className="flex items-start gap-3 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <Calendar className="w-5 h-5 text-blue-600 mt-0.5" />
                  <div>
                    <p className="font-semibold text-blue-900">
                      {upcomingMaintenances} manutenções agendadas
                    </p>
                    <p className="text-sm text-blue-700 mt-1">
                      Próximos 7 dias
                    </p>
                  </div>
                </div>
              )}

              {needsMaintenance === 0 && equipmentExpiringSoon.length === 0 && upcomingMaintenances === 0 && (
                <div className="flex items-center gap-3 p-6 bg-green-50 border border-green-200 rounded-lg">
                  <CheckCircle2 className="w-6 h-6 text-green-600" />
                  <p className="font-medium text-green-900">
                    Tudo em ordem! Não há alertas no momento.
                  </p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <Card className="border-none shadow-lg">
          <CardHeader className="border-b border-slate-100">
            <CardTitle className="flex items-center gap-2 text-slate-900">
              <TrendingUp className="w-5 h-5 text-green-500" />
              Estatísticas Rápidas
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6 space-y-4">
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="text-sm text-slate-600">Concluídas este mês</span>
              <span className="text-xl font-bold text-slate-900">{completedThisMonth}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="text-sm text-slate-600">Taxa de conformidade</span>
              <span className="text-xl font-bold text-green-600">
                {totalEquipment > 0 ? Math.round(((totalEquipment - needsMaintenance) / totalEquipment) * 100) : 0}%
              </span>
            </div>
            <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
              <span className="text-sm text-slate-600">Equipamentos conformes EN54</span>
              <span className="text-xl font-bold text-blue-600">
                {equipment.filter(e => e.en54_compliant).length}
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Maintenances */}
      <Card className="border-none shadow-lg">
        <CardHeader className="border-b border-slate-100">
          <CardTitle className="flex items-center gap-2 text-slate-900">
            <Calendar className="w-5 h-5 text-blue-500" />
            Manutenções Recentes
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          {recentMaintenances.length > 0 ? (
            <div className="space-y-3">
              {recentMaintenances.map((maintenance) => (
                <div key={maintenance.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
                  <div className="flex-1">
                    <p className="font-semibold text-slate-900">{maintenance.type?.replace(/_/g, ' ')}</p>
                    <p className="text-sm text-slate-500">
                      {format(new Date(maintenance.scheduled_date), "dd 'de' MMMM, yyyy", { locale: pt })}
                    </p>
                  </div>
                  <Badge className={
                    maintenance.status === 'completed' ? 'bg-green-100 text-green-800' :
                    maintenance.status === 'in_progress' ? 'bg-blue-100 text-blue-800' :
                    maintenance.status === 'scheduled' ? 'bg-orange-100 text-orange-800' :
                    'bg-slate-100 text-slate-800'
                  }>
                    {maintenance.status === 'completed' ? 'Concluída' :
                     maintenance.status === 'in_progress' ? 'Em Progresso' :
                     maintenance.status === 'scheduled' ? 'Agendada' :
                     maintenance.status}
                  </Badge>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-slate-500 py-8">Nenhuma manutenção registada</p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}