import Layout from "./Layout.jsx";

import Dashboard from "./Dashboard";

import Clients from "./Clients";

import Installations from "./Installations";

import Equipment from "./Equipment";

import Maintenance from "./Maintenance";

import Technicians from "./Technicians";

import Reports from "./Reports";

import ChecklistTemplates from "./ChecklistTemplates";

import Licensing from "./Licensing";

import EmailSettings from "./EmailSettings";

import Users from "./Users";

import Roles from "./Roles";

import AIAssistant from "./AIAssistant";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Dashboard: Dashboard,
    
    Clients: Clients,
    
    Installations: Installations,
    
    Equipment: Equipment,
    
    Maintenance: Maintenance,
    
    Technicians: Technicians,
    
    Reports: Reports,
    
    ChecklistTemplates: ChecklistTemplates,
    
    Licensing: Licensing,
    
    EmailSettings: EmailSettings,
    
    Users: Users,
    
    Roles: Roles,
    
    AIAssistant: AIAssistant,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Dashboard />} />
                
                
                <Route path="/Dashboard" element={<Dashboard />} />
                
                <Route path="/Clients" element={<Clients />} />
                
                <Route path="/Installations" element={<Installations />} />
                
                <Route path="/Equipment" element={<Equipment />} />
                
                <Route path="/Maintenance" element={<Maintenance />} />
                
                <Route path="/Technicians" element={<Technicians />} />
                
                <Route path="/Reports" element={<Reports />} />
                
                <Route path="/ChecklistTemplates" element={<ChecklistTemplates />} />
                
                <Route path="/Licensing" element={<Licensing />} />
                
                <Route path="/EmailSettings" element={<EmailSettings />} />
                
                <Route path="/Users" element={<Users />} />
                
                <Route path="/Roles" element={<Roles />} />
                
                <Route path="/AIAssistant" element={<AIAssistant />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}